#!/opt/local/bin python
#import sys
#sys.path.reverse()

    #   Earthquake Methods library of methods and functions
    #   
    #   This code base collects the methods and functions used to make
    #   plots and maps of earthquake data and activity
    #
    ######################################################################

import sys
import matplotlib
import matplotlib.mlab as mlab
#from matplotlib.pyplot import figure, show
import numpy as np
from numpy import *

from array import array
import matplotlib.pyplot as plt
from matplotlib import gridspec
import matplotlib.patches as patches

import datetime
import dateutil.parser

import urllib.request, urllib.parse, urllib.error
import urllib.request, urllib.error, urllib.parse
import os

import math
from math import exp

import MCUtilities
from MCUtilities import *

from matplotlib import cm

import http.client
from urllib.error import HTTPError

from shapely.geometry import Point
from shapely.geometry.polygon import Polygon

import random
import operator

import requests
from itertools import product

    ######################################################################
    

def mean_val(number_array):

    #   The obvious: returns the mean of an array of numbers

    N_Dim_mean = len(number_array)
    mean = sum(number_array)/float(N_Dim_mean)

    return mean

    #   .................................................................

def std_var_val(number_array):

    #   The obvious: returns the standard deviation of an array of numbers

    N_Dim_var = len(number_array)
    mean_of_array = mean_val(number_array)

    adjusted_arguments = [((i-mean_of_array)**2)/float(N_Dim_var-1) for i in number_array]   # Sample variance

    variance = sum(adjusted_arguments)   

    standard_deviation = math.sqrt(variance) 

    return (standard_deviation, variance)
    
    #   .................................................................
    
def calc_random_cdf(number_small_eqs_excluding_last, num_bins):

    #   This method calculates a random CDF for use in the bootstrap
    #       uncertainty analysis
    
    number_intervals = len(number_small_eqs_excluding_last)
    
    random_intervals = []

    for i in range(number_intervals):
        bootstrap_interval = random.choice(number_small_eqs_excluding_last)
        random_intervals.append(bootstrap_interval)
        
    n, bins = histogram(random_intervals, num_bins)
    
    cum_prob_random = np.zeros(len(bins))
    
    for i in range(1,len(bins)):
        cum_prob_random[i] = cum_prob_random[i-1] +  n[i-1]

    #   Calc cumulative probability

    cum_prob_random[:] = cum_prob_random[:]/ float(sum(n))
    
    cum_prob_random[:] = cum_prob_random[:] *100.0
    
    cum_prob_random    = np.append(cum_prob_random, 100.0)

    return cum_prob_random
    
    #   .................................................................
    
def calc_random_bands(cum_prob, number_small_eqs_excluding_last, num_bins, todays_count, number_cdfs):

    #   This method calculates a the 1-sigma uncertainty bands for random CDFs
    #       using a bootstrap uncertainty analysis
    
    number_intervals = len(number_small_eqs_excluding_last)
    
    cum_prob_random_low     =   []
    cum_prob_random_high    =   []
    cum_prob_random_mean    =   []
    cum_prob_list           =   []
    
    for k in range(number_cdfs):
        random_intervals = []

        for i in range(number_intervals):
            bootstrap_interval = random.choice(number_small_eqs_excluding_last)
            random_intervals.append(bootstrap_interval)
        
        n, bins = histogram(random_intervals, num_bins)
    
        cum_prob_random = np.zeros(len(bins))
    
        for i in range(1,len(bins)):
            cum_prob_random[i] = cum_prob_random[i-1] +  n[i-1]

    #   Calc cumulative probability

        cum_prob_random[:] = cum_prob_random[:]/ float(sum(n))
        cum_prob_random[:] = cum_prob_random[:] *100.0
        cum_prob_random    = np.append(cum_prob_random, 100.0)
        
        cum_prob_list.append(cum_prob_random)
        
    number_elements = len(cum_prob_random)
    
    mean_values_list     =   []
    stdev_values_list    =   []
    
    for j in range(number_elements):                #   Number of probability values in the cdf
        values_list = []
        
        for m in range(number_cdfs):                #   Loop over number of cdfs
        
            values_list.append(cum_prob_list[m][j]) #   First index is cdf, second index is bin number
            
        mean_cdf   = mean_val(values_list)
        stdev_cdf, variance_cdf  = std_var_val(values_list)
        
        mean_values_list.append(mean_cdf)
        stdev_values_list.append(stdev_cdf)
        
#     print mean_values_list
#     print ''
#     print stdev_values_list
#     print ''
#     
    cum_prob_random_mean    = mean_values_list[:]
    cum_prob_random_low     = list(map(operator.sub,cum_prob, stdev_values_list))
    cum_prob_random_high    = list(map(operator.add,cum_prob, stdev_values_list))
    
    todays_stdev = 0
    
    for n in range(len(bins)):
        if todays_count >= bins[n]:
            todays_stdev = stdev_values_list[n]
        
#    print cum_prob_list

    return cum_prob_random_mean, cum_prob_random_low, cum_prob_random_high, todays_stdev

