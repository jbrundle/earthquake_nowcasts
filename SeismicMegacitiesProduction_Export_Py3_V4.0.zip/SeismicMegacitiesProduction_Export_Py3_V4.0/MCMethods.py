#!/opt/local/bin python
#import sys
#sys.path.reverse()

    #   Earthquake Methods library of methods and functions
    #   
    #   This code base collects the methods and functions used to make
    #   plots and maps of earthquake data and activity
    #
    ######################################################################

import sys
import matplotlib
import matplotlib.mlab as mlab
#from matplotlib.pyplot import figure, show
import numpy as np
from numpy import *

from array import array
import matplotlib.pyplot as plt
from matplotlib import gridspec
import matplotlib.patches as patches

import datetime
import dateutil.parser

import urllib.request, urllib.parse, urllib.error
import urllib.request, urllib.error, urllib.parse
import os

import math
from math import exp

import MCUtilities
from MCUtilities import *
import MCCalcMethods

from matplotlib import cm

import http.client
from urllib.error import HTTPError

from shapely.geometry import Point
from shapely.geometry.polygon import Polygon

import cartopy
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.offsetbox import AnchoredText
from matplotlib.image import imread

import cartopy.io.img_tiles as cimgt
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
from cartopy.feature import NaturalEarthFeature, LAND, COASTLINE, BORDERS, STATES, RIVERS, LAKES


    ######################################################################

    # Set the catalog parameters
    
def get_current_date_time():

    now = datetime.datetime.now()

    print("Current year: %d" % now.year)
    print("Current month: %d" % now.month)
    print("Current day: %d" % now.day)
    print("Current hour: %d" % now.hour)
    print("Current minute: %d" % now.minute)
    print("Current second: %d" % now.second)
    
    slash = '/'
    colon = ':'
    
    year  = str(now.year)
    month = str(now.month)
    day   = str(now.day)
    
    if now.month < 10:
        month = '0'+ str(now.month)
        
    if now.day < 10:
        day = '0'+ str(now.day)
    
    current_date = year + slash + month + slash + day
    current_time = str(now.hour) + colon + str(now.minute) + colon + str(now.second)
    
    return (current_date, current_time, year, month, day)

    
def get_master_catalog(NELat, NELng, SWLat, SWLng, Magnitude):

#   This code will use shapely.py to filter the worldwide catalog
#       into a rectangular region

    settings_params = get_settings()
    region_type = settings_params[0]
    location = settings_params[3]

    data_string = 'Building catalog for region around ' + location + '...'
    
    print('')
    print('------------------------------------------')
    print('')
    print(data_string)
    print('')
    print('------------------------------------------')
    print('')

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])
        settings_params[1] = completeness_mag
        settings_params[2] = earthquake_depth
        save_settings(settings_params)

    output_file_name = "USGS_master.catalog"
    output_file = open(output_file_name, "w")
    output_file.close()

    number_polygon_vertices = 4

    #   Construct the string of polygon vertices.  Note that the order is lat, long pairs
    
    vertex_lat = []
    vertex_lng = []
    
    #   Order of vertices of large rectangular region:  NW, NE, SE, SW
    
    vertex_lat.append(NELat)
    vertex_lat.append(NELat)
    vertex_lat.append(SWLat)
    vertex_lat.append(SWLat)
    
    vertex_lng.append(SWLng)
    vertex_lng.append(NELng)
    vertex_lng.append(NELng)
    vertex_lng.append(SWLng)
    
    point_list = []

    for i in range(number_polygon_vertices):
        point_list.append((float(vertex_lat[i]),float(vertex_lng[i])))
    
    polygon = Polygon(point_list)
#       

    input_file_name     = "USGS_Base.catalog"
    input_file          =  open(input_file_name, "r")

    output_file_name = "USGS_master.catalog"
    output_file = open(output_file_name, "w")
    
    for line in input_file:
        items = line.strip().split()
        try:
            dep    = items[6]
            mag    = items[5]
            eq_lat = items[4]
            eq_lng = items[3]
        
            point = Point((float(eq_lat),float(eq_lng)))
        
            if (float(dep) <= float(earthquake_depth) and float(mag) >= float(completeness_mag) and polygon.contains(point) == True):
#               print items[0],items[1],items[2],items[3],items[4],items[5],items[6]
                print(items[0],items[1],items[2],items[3],items[4],items[5],items[6], file=output_file)
                
        except:
            pass
        
    output_file.close()
    input_file.close()

    return
    
def get_circle_master_catalog(Latitude,Longitude,Radius,Magnitude):

#   This code will use shapely.py to filter the worldwide catalog
#       into a rectangular region

    settings_params = get_settings()
    region_type = settings_params[0]
    location = settings_params[3]

    data_string = 'Building circle catalog for region around ' + location + '...'
    
#     print ''
#     print '------------------------------------------'
#     print ''
#     print data_string
#     print ''
#     print '------------------------------------------'
#     print ''

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])
        settings_params[1] = completeness_mag
        settings_params[2] = earthquake_depth
        save_settings(settings_params)

    output_file_name = "USGS_circle.master.catalog"
    output_file = open(output_file_name, "w")
    output_file.close()

    #   Compute vertices that define the circle around the city
    
    lng_circle_dg, lat_circle_dg = MCUtilities.createCircleAroundWithRadius(Latitude, Longitude, Radius)
    
    number_polygon_vertices = len(lng_circle_dg)
    
    point_list = []

    for i in range(number_polygon_vertices):
        point_list.append((float(lat_circle_dg[i]),float(lng_circle_dg[i])))
    
    polygon = Polygon(point_list)
    
#   print point_list
#       

    input_file_name     = "USGS_Base.catalog"
    input_file          =  open(input_file_name, "r")

    output_file_name = "USGS_circle.master.catalog"
    output_file = open(output_file_name, "w")
    
    for line in input_file:
        items = line.strip().split()
        try:
            dep    = items[6]
            mag    = items[5]
            eq_lat = items[4]
            eq_lng = items[3]
        
            point = Point((float(eq_lat),float(eq_lng)))
        
            if (float(dep) <= float(earthquake_depth) and float(mag) >= float(completeness_mag) and polygon.contains(point) == True):
#               print items[0],items[1],items[2],items[3],items[4],items[5],items[6]
                print(items[0],items[1],items[2],items[3],items[4],items[5],items[6], file=output_file)
        except:
            pass
        
    output_file.close()
    input_file.close()

    return None
    
        #############################################################

def get_catalog(NELat, NELng, SWLat, SWLng, MagLo):

    settings_params = get_settings()
    region_type = settings_params[0]
    location = settings_params[3]

    data_string = 'Building regional catalog for large region centered on ' + location + '...'
    
#     print ''
#     print '------------------------------------------'
#     print ''
#     print data_string
#     print ''
#     print '------------------------------------------'
#     print ''

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])
        settings_params[1] = completeness_mag
        settings_params[2] = earthquake_depth
        save_settings(settings_params)

    #############################################################
    
        #   This method now calls the get_master_catalog() method which writes
    #       the master catalog.  All the other get_catalog-type methods
    #       will open and filter the master

    #    completeness_mag = 2.99
    
    get_master_catalog(NELat, NELng, SWLat, SWLng, completeness_mag)

    #   Write output record file

    # Open the master output file to read
    output_master = open("USGS_master.catalog", "r")

    #   Now write the output file.  So first, open the output file for the last events
#    output = open("USGS_master.catalog", "w")

    #   Now write the output_last file.  So first, open the output file for the last events
    output_last = open("USGS_last.catalog", "w")

    # Format the data

    i=-1
    for line in output_master:
        i+=1
        items = line.strip().split()
        
        lat                 = items[4]
        lon                 = items[3]
        dep                 = items[6]
        mag                 = items[5]
        date_string         = items[0]
        time_string         = items[1]
        ts                  = items[2]
        
    #   These next checks are in case depths are missing, or depths & mags are listed as 'Unk'

    #   print lat,lon,dep,mag,date_string,time_string

#       if (float(dep) <= float(earthquake_depth)):
#            output.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (date_string, time_string, ts, lon, lat, mag, dep))

        if (float(dep) <= float(earthquake_depth)):
            output_last.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (date_string, time_string, ts, lon, lat, mag, dep))

    #   We use only the small earthquakes after the last large earthquake. So if this event is not the last
    #       large event, close the file, move the pointer to the top, and re-open the file for writing

        if (float(mag) >= float(MagLo)):
            output_last.close()
            output_last = open("USGS_last.catalog", "w")           

    # Finalize the output file
    output_master.close()
#    output.close()
    output_last.close()

    print(' ')
    print('     Read in Catalog Date, now Building Working File')

    #############################################################

    #   Now Write the Output Working File

    #############################################################

    #   First count number of lines in master data file that we just downloaded above   

    data_file = open("USGS_master.catalog", "r")

    #   Now open the working file where we will re-write the data

    j=0
    for line in data_file:
        j+=1
    h=j

    data_file.close()
    data_file = open("USGS_master.catalog", "r") # Put the file pointer back at the top


    working_file = open("EQ_Working_Catalog.txt", "w")
    
    print('')
    
    i=0
    j=0
    for line in data_file:
        j+=1
        items = line.strip().split()
    #
        percent_complete = 100.0*float(j)/float(h) 
        print('     Percent File Completed: ', "{0:.2f}".format(percent_complete),'%', "                                 \r", end=' ')   

    #
    #   Remember that at this point, all the below variables are string variables, not floats
    #

        date_string         = items[0]
        time_string         = items[1]
        ts                  = items[2]
        lon                 = items[3]
        lat                 = items[4]
        mag                 = items[5]
        dep                 = items[6]

        lat     = 0.0001*float(int(10000.0*float(lat + '000000')))

        if float(mag) >= MagLo:
            i+=1
            event = str(i)
            if i <10:
                event = '0'+str(i)

            working_file.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (event, date_string, time_string, ts, lon, lat, mag, dep))
            sys.stdout.flush()
            
    print('')

    # Finalize the output file

    working_file.close()
    data_file.close()

    return None
    
    ######################################################################

    # Set the catalog parameters for circular region

def get_circle_catalog(Circle_Lat, Circle_Lng, Radius_float, MagLo, Rebuild_flag):

    settings_params = get_settings()
    region_type = settings_params[0]
    location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])
        
    print('completeness_mag: ', completeness_mag)

    if Rebuild_flag == 'OFF':
        data_string = 'Building catalog for  M>' + str(completeness_mag) + ' for small circle around ' + location + '...'
        
    if Rebuild_flag == 'ON':
            data_string = 'Rebuilding catalog for M>' + str(completeness_mag) + ' for small circle around ' + location 
    
    print('')
    print('------------------------------------------')
    print('')
    print(data_string)
    print('')
    print('------------------------------------------')
    print('')

    #############################################################
    
    get_circle_master_catalog(Circle_Lat, Circle_Lng, Radius_float, completeness_mag)
    
    # Open the master output file to read
    output_circle_master = open("USGS_circle.master.catalog", "r")

    #   Write output record file

    # Open the output file
    output = open("USGS_circle.catalog", "w")
    output_last_circle = open("USGS_last.circle.catalog", "w")      

    # Format the data

    mag_array   =   []
    date_array  =   []
    time_array  =   []
    year_array  =   []
    depth_array =   []
    lat_array   =   []
    lng_array   =   []

    i=-1
    for line in output_circle_master:
        i+=1
        items = line.strip().split()

        try:
        
            lat                 = items[4]
            lon                 = items[3]
            dep                 = items[6]
            mag                 = items[5]
            date_string         = items[0]
            time_string         = items[1]
            ts                  = items[2]

            mag_array.append(mag)           #   List of magnitudes
            date_array.append(date_string)
            time_array.append(time_string)
            year_array.append(ts)
            depth_array.append(dep)
            lat_array.append(lat)
            lng_array.append(lon)

            if (float(dep) <= float(earthquake_depth)):
                output.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (date_string, time_string, ts, lon, lat, mag, dep))

    #       print lat,lon,dep,mag,date_string,time_string

            if (float(dep) <= float(earthquake_depth)):
                output_last_circle.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (date_string, time_string, ts, lon, lat, mag, dep))

    #   We use only the small earthquakes after the last large earthquake. So if this event is not the last
    #       large event, close the file, move the pointer to the top, and re-open the file for writing

            if (float(mag) >= float(MagLo)):
                output_last_circle.close()
                output_last_circle = open("USGS_last.circle.catalog", "w")      

        except:
           pass

    # Finalize the output file
    output_circle_master.close()
    output.close()
    output_last_circle.close()

    #############################################################

    #   Now Write the Output Working File

    #############################################################

    #   First count number of lines in master data file that we just downloaded above

    data_file = open("USGS_circle.catalog", "r")

    #   Now open the working file where we will re-write the data

    j = 0
    for line in data_file:
        j += 1
    h = j

    data_file.close()
    data_file = open("USGS_circle.catalog",
                     "r")  # Put the file pointer back at the top

    os.system("rm EQ_Working_Circle_Catalog.txt")

    working_file = open("EQ_Working_Circle_Catalog.txt", "w")
    
    print('')
    
    i = 0
    j = 0
    for line in data_file:
        j += 1
        items = line.strip().split()

        percent_complete = 100.0 * float(j) / float(h)
        print('     Percent File Completed: ', "{0:.2f}".format(
            percent_complete), '%', "                                 \r", end=' ')

        #
        #   Remember that at this point, all the below variables are string variables, not floats
        #

        date_string = items[0]
        time_string = items[1]
        ts = items[2]
        lon = items[3]
        lat = items[4]
        mag = items[5]
        dep = items[6]

        lat = 0.0001 * float(int(10000.0 * float(lat + '000000')))

        if float(mag) >= MagLo:
            i += 1
            event = str(i)
            if i < 10:
                event = '0' + str(i)

            working_file.write(
                "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (event, date_string, time_string, ts, lon, lat, mag, dep))
            sys.stdout.flush()

    # Finalize the output file
    
    print('')

    working_file.close()
    data_file.close()

    return mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array
    
def read_circle_catalog():

    mag_array   =   []
    date_array  =   []
    time_array  =   []
    year_array  =   []
    depth_array =   []
    lat_array   =   []
    lng_array   =   []

    data_file = open("USGS_circle.catalog","r")
    
    for line in data_file:
        items = line.strip().split()
        
        try:
        
            lat                 = items[4]
            lon                 = items[3]
            dep                 = items[6]
            mag                 = items[5]
            date_string         = items[0]
            time_string         = items[1]
            ts                  = items[2]

            mag_array.append(mag)           #   List of magnitudes
            date_array.append(date_string)
            time_array.append(time_string)
            year_array.append(ts)
            depth_array.append(dep)
            lat_array.append(lat)
            lng_array.append(lon)
            
        except:
            pass
    
    data_file.close()  

    return mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array

    ######################################################################

def histogram_eps_region(NELat, NELng, SWLat, SWLng, MagLo, Location):

    print_data = 'TRUE'

    last_droplet_plot   =   'n'


    #   Open input file

    input_file = open("EQ_Working_Catalog.txt", "r")

    #   Find the number of lines in the file

    i=0
    for line in input_file:
        i       +=  1

    input_file.close()  # Put the file pointer back at top

    number_eqs = i

    input_file = open("EQ_Working_Catalog.txt", "r")

    # Create arrays of length i filled with zeros

    indx_string         =   ["" for x in range(number_eqs)]
    yrs                 =   zeros(number_eqs)
    lng                 =   zeros(number_eqs)
    lat                 =   zeros(number_eqs)
    mag                 =   zeros(number_eqs)
    dep                 =   zeros(number_eqs)

    time_string         =   ["" for x in range(number_eqs)]
    date_string         =   ["" for x in range(number_eqs)]

    # Bins for Number-magnitude plot

    min_mag = 3.0
    bin_diff= 0.1

    number_mag_bins     =   (MagLo - min_mag) / bin_diff + 1      #   Bin size = 0.1.  Assume min mag of interest is 3.0
    number_mag_bins     =   int(number_mag_bins)
    range_mag_bins      =   int(number_mag_bins)

    freq_mag_bins_pdf       =   zeros(number_mag_bins)
    freq_mag_bins_sdf       =   zeros(number_mag_bins)
    freq_mag_pdf_working    =   zeros(number_mag_bins)
    mag_array               =   zeros(number_mag_bins)  

    # Loop over lines and extract variables of interest

    i=-1
    eq_sequence_number = 0

    for line in input_file:
        line = line.strip()
        data = line.split()
        data_array = np.asarray(data)

        i       +=  1

        indx_string[i] =   data_array[0]
        date_string[i] =   data_array[1]
        time_string[i] =   data_array[2]

        yrs[i]     =    float(data_array[3])
        lng[i]     =    float(data_array[4])
        lat[i]     =    float(data_array[5])
        mag[i]     =    float(data_array[6])
        dep[i]     =    float(data_array[7])

    # Format and print the earthquake sequence numbers

        if mag[i] >= MagLo:
            eq_sequence_number += 1

        last_eq = eq_sequence_number

    input_file.close()  # Put the file pointer back at top


    #.................................................................

     #   The large earthquakes were renumbered to start from 1 so need to correct for that

    first_eq    = int(0)
    second_eq   = int(last_eq) - 1

    number_of_eq_cycles = last_eq - first_eq


    #.................................................................
    

    #   Now open the complete data file so that we can retrieve the small earthquakes    

    #   Count the number of small earthquakes in each cycle and store in array for binning
    #       and plotting in histogram

    number_small_eq_array   =   np.zeros(number_eqs)

    data_file = open("USGS_master.catalog", "r")     #  This is all the data and all the small events

    index_large_eq = -1             #   So the first large earthquake cycle will have index 0
    large_eq_flag = 'FALSE'

    for line in data_file:
        items   = line.strip().split()
        mag_query           = float(items[5])

        if mag_query < MagLo:
            date_small_quake    = items[0]
            time_small_quake    = items[1]

        if mag_query >= MagLo:
            large_eq_flag = 'TRUE'  #   Takes care of initial state where there is no initial large earthquake
            number_in_cycle =  0
            index_large_eq += 1
        if (mag_query < MagLo) and (large_eq_flag == 'TRUE'):
            number_small_eq_array[index_large_eq] += 1
    
    data_file.close()               #   Close the data file

    print(' ')
    print('       Large EQ', '      Date and Time', '       Magnitude', '   Latitude', '    Longitude', '    Number Small EQs (After this large EQ)')
    print(' ')

    total_number_small_eqs = 0
    eq_limit = second_eq-first_eq +1  
    for i in range(first_eq,eq_limit):
        total_number_small_eqs += number_small_eq_array[i]
        if i+1 <10:
            blank_space = '         '
        if i+1 >=10:
            blank_space = '        '
        if i+1 >=100:
            blank_space = '       '
        print(blank_space, i+1, '     ', date_string[i] + ' ' + time_string[i], '     ', '%.2f'%mag[i], '     ', '%.3f'%(lat[i]), '    ', '%.3f'%lng[i],  \
                '          ',int(number_small_eq_array[i]))

    #.................................................................

    City = Location
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]

    range_limit = len(lat)

    print_text_1 = '     Found ' + str(number_eqs) + ' earthquakes having M>' + str(MagLo) + ' around ' + City_Location
    print_text_2 = '     Occurring from: ' + date_string[0] + ' ' + time_string[0] 
    print_text_3 = '               thru: ' + date_string[number_eqs-1] + ' ' + time_string[number_eqs - 1]
    print(' ')
    print(print_text_1)
    print(' ')
    print(print_text_2)
    print(print_text_3)
    print('')
    print('     Total Number of Small Earthquakes: ', int(total_number_small_eqs))        
    print('')


   #.................................................................

#   num_bins = 100
    num_bins = 200

    #   Histogram the data

    #   n[i] below is an array with the number of intervals in bin [i]
    #   bins[i] is an array with the location of the bin center
    #   patches[i] is an array with descriptions of each histogram rectangle
    #   set normed = 1 if you want the histogram to be a pdf

    #    n, bins, patches = plt.hist(number_small_eq_array, num_bins, facecolor='green', edgecolor='black',   alpha=0.5)

    todays_count = number_small_eq_array[last_eq-1]

    number_small_eqs_excluding_last = np.zeros(number_eqs-1)

    for i in range(0,number_eqs-1):
        number_small_eqs_excluding_last[i] = number_small_eq_array[i]

    mean    =   mean_val(number_small_eqs_excluding_last)
    std_deviation, variance = std_var_val(number_small_eqs_excluding_last)

    mean_eqs = mean

    mean_small_EQs = '%.2f'%mean
    std_dev_small_EQs = '%.2f'%std_deviation  

    print('         Mean Number of Small Earthquakes: ', mean_small_EQs)
    print('     Standard Deviation Small Earthquakes: ', std_dev_small_EQs)
    print('')

    #.................................................................

    #   Bin the data

    todays_probability = 0.0

    n, bins = histogram(number_small_eqs_excluding_last, num_bins)

    #   -----------------------------------------


    cum_poisson = np.zeros(len(bins))   #   Cumulative Poisson distribution

    cum_prob = np.zeros(len(bins))

    for i in range(1,len(bins)):
        cum_prob[i] = cum_prob[i-1] +  n[i-1]
        cum_poisson[i] = 1.0 - math.exp(-bins[i]/float(mean_small_EQs))

    cum_poisson[:] = (cum_poisson[:]) * 100.0

    #   Calc cumulative probability

    cum_prob[:] = cum_prob[:]/ float(last_eq)

    scale_factor = 100.0/cum_prob[len(bins)-1]

    cum_prob[:] = cum_prob[:]*scale_factor	#   Ensures that cum prob goes from 0%->100%

#    cum_prob[:] = cum_prob[:] *100.0
    cum_prob[:] = cum_prob[:]

    for i in range(1, len(bins)):
        if todays_count >= bins[i]:
            todays_probability = cum_prob[i]

#    mean_eqs = mean_eqs*1.45   #   Test statement

    tau_best, beta_best, sdev_tau, sdev_beta, sum_of_squares_low = weibullBetaFit(n, bins, cum_prob, mean_eqs)

    tau_string   = "{0:.2f}".format(tau_best) + ' +/- '  + "{0:.2f}".format(sdev_tau)
    beta_string  = "{0:.2f}".format(beta_best) + ' +/- ' + "{0:.2f}".format(sdev_beta)

    print('')
    print(' Weibull fit data: ')
    print('')
    print(' Tau: ', tau_string)
    print('Beta: ', beta_string)
    print('')

    cum_weibull =   np.zeros(len(bins)+1)

    for i in range(0,len(bins)):
        arg_weibull = ((bins[i]/tau_best)**beta_best)
        cum_weibull[i] = 1.0 - math.exp(- arg_weibull)

    cum_weibull[:] = cum_weibull[:] *100.0


    #.................................................................

    #   Define the Temperature

    temperature = "{0:.1f}".format(todays_probability)+'%'

    #.................................................................

    #  Plot the data

    fig = plt.figure(figsize=(8, 6))        #   Define large figure and thermometer - 4 axes needed

    gs = gridspec.GridSpec(1,2,width_ratios=[14, 1], wspace = 0.2) 
    ax0 = plt.subplot(gs[0])

    #   Draw the bins

    ax0.hist(number_small_eq_array, num_bins, facecolor='green', edgecolor='black',   alpha=0.5)

    #   Get the axis limits

    ymin, ymax = ax0.get_ylim()
    xmin, xmax = ax0.get_xlim()

    todays_date          =  datetime.date.today().strftime("%B %d, %Y")
    SupTitle_text = 'Potential for M>' + str(MagLo) + ' Earthquakes in ' + Location + ' on ' + todays_date
    SupTitle_text = 'Potential for M>' + str(MagLo) + ' Earthquakes in ' + Location
    Title_text    = 'After M' + '%.2f'%mag[last_eq-1] + ' on ' + date_string[last_eq-1] + ' at ' + time_string[last_eq-1]

    plt.xlabel('Number of Small Earthquakes Between Large Earthquakes')
    plt.ylabel('Number of Earthquake Intervals')

    #   Write the legends on the plot

    text_x1          = (xmax-xmin)*0.40 + xmin
    text_y1          = (ymax-ymin) * 0.90 + ymin

    text_x2          = (xmax-xmin)*0.40 + xmin
    text_y2          = (ymax-ymin) * 0.85 + ymin

    count_string    = str(int(todays_count))
    text_string1 = 'Todays Small EQ Count:  ' + count_string 
    text_string2 = 'On:  ' + date_small_quake + '   at:  ' + time_small_quake
    plt.text(text_x1,text_y1,text_string1, fontsize=12)    
    plt.text(text_x2,text_y2,text_string2, fontsize=12)    

    text_x      = (xmax-xmin)*0.40 + xmin
    text_y      = (ymax-ymin) * 0.77 + ymin
    prob        = '%.1f'%(todays_probability)
    text_string = 'Todays EPS Value:  ' + prob +'%'
    plt.text(text_x,text_y,text_string, fontsize=12)    

    text_x      = (xmax-xmin)*0.40 + xmin
    text_y      = (ymax-ymin) * 0.70 + ymin
    text_string = 'Weibull Parameters: '
    plt.text(text_x,text_y,text_string, fontsize=12)    

    text_x1          = (xmax-xmin)*0.40 + xmin
    text_y1          = (ymax-ymin) * 0.65 + ymin

    text_x2          = (xmax-xmin)*0.40 + xmin
    text_y2          = (ymax-ymin) * 0.60 + ymin

    count_string    = str(int(todays_count))
    text_string1 = '    Tau:  ' + tau_string 
    text_string2 = '   Beta:  ' + beta_string
    plt.text(text_x1,text_y1,text_string1, fontsize=12)    
    plt.text(text_x2,text_y2,text_string2, fontsize=12)    

    #.................................................................

    # Main plot

    plt.suptitle(SupTitle_text, fontsize=14)
    plt.title(Title_text, fontsize=12) 

    bins        = np.append(bins,bins[num_bins])
    cum_prob    = np.append(cum_prob, 100.0)
    cum_poisson = np.append(cum_poisson, 100.0)

    ax1 = ax0.twinx()

    plt.ylim(ymax = 100, ymin = 0)
    plt.xlim(xmax=max(bins), xmin=0)
    ymin, ymax = ax1.get_ylim()

    ax1.plot(bins,cum_weibull, 'g-', lw=1.2)    #   Uncomment if you want to plot the Weibull curve with same mean
#   ax1.plot(bins,cum_poisson, 'b--')    #   Uncomment if you want to plot the Poisson curve with same mean
    ax1.plot(bins,cum_prob, 'r-')

    ax1.get_yaxis().set_ticks([0.,25, 50, 75, 100])
    ax1.plot([xmin,xmax],[50,50], 'b', ls='dotted')
    ax1.plot([xmin,xmax],[25,25], 'b', ls='dotted')
    ax1.plot([xmin,xmax],[75,75], 'b', ls='dotted')
    ax1.plot([todays_count,xmax],[todays_probability,todays_probability], 'r', ls='dashed', lw=1)
    x=[todays_count, todays_count]
    y=[0,todays_probability]
    ax1.plot(x,y, 'r', ls='dashed', lw=1)
    ax1.plot([todays_count], [todays_probability], 'ro', ms=8)
    x=[mean_small_EQs,mean_small_EQs]
    y=[0,100]
    ax1.plot(x,y, 'k', ls='dotted')


    #.................................................................

    #   Thermometer

    ax3 = plt.subplot(gs[1])
    frame1 = plt.gca()
    plt.ylim([0,1])                         #   Show the y-axis labels
    plt.xlim([0,1])                         #   Set the x-axis limits  

    frame1.axes.get_xaxis().set_ticks([])   #   Hide the x-axis ticks and labels
    frame1.axes.get_yaxis().set_ticks([])

    ax4 = ax3.twinx()
    plt.ylim([0,100])                         #   Show the y-axis labels
    plt.xlim([0,1])

    ax4.get_yaxis().set_ticks([])
#    ax4.set_ylabel('Seismic "Temperature" = Current Cumulative Probability (%)', rotation=90)
    x=[0.0,1.0]
    y=[todays_probability,todays_probability]
    ax4.fill_between(x,0,y, alpha=0.75, facecolor='red')
    
    ax4.plot([0,1],[50,50], 'b', ls='dotted', lw=1)
    ax4.plot([0,1],[25,25], 'b', ls='dotted', lw=1)
    ax4.plot([0,1],[75,75], 'b', ls='dotted', lw=1)

    #.................................................................

    print('')
    print('Todays small earthquake count is: ', int(todays_count))

    print('Todays EPS Value (Cumulative Probability) is: ', temperature)
    print('')

    matplotlib.pyplot.savefig('EPS-Region.png',dpi=300)

    plt.show()

    return None

    ######################################################################

def histogram_eps_region_circle(NELat, NELng, SWLat, SWLng, MagLo, min_mag, Location):

    settings_params = get_settings()
    region_type = settings_params[0]
    location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])
        
    print_data = 'TRUE'

    last_droplet_plot   =   'n'

    #   Open input file

    input_file = open("EQ_Working_Catalog.txt", "r")

    #   Find the number of lines in the file

    i=0
    for line in input_file:
        i       +=  1

    input_file.close()  # Put the file pointer back at top

    number_eqs = i

    input_file = open("EQ_Working_Catalog.txt", "r")

    # Create arrays of length i filled with zeros

    indx_string         =   ["" for x in range(number_eqs)]
    yrs                 =   zeros(number_eqs)
    lng                 =   zeros(number_eqs)
    lat                 =   zeros(number_eqs)
    mag                 =   zeros(number_eqs)
    dep                 =   zeros(number_eqs)

    time_string         =   ["" for x in range(number_eqs)]
    date_string         =   ["" for x in range(number_eqs)]

    # Loop over lines and extract variables of interest

    i=-1
    eq_sequence_number = 0

    for line in input_file:
        line = line.strip()
        data = line.split()
        data_array = np.asarray(data)

        i       +=  1

        indx_string[i] =   data_array[0]
        date_string[i] =   data_array[1]
        time_string[i] =   data_array[2]

        yrs[i]     =    float(data_array[3])
        lng[i]     =    float(data_array[4])
        lat[i]     =    float(data_array[5])
        mag[i]     =    float(data_array[6])
        dep[i]     =    float(data_array[7])

    # Format and print the earthquake sequence numbers

        if mag[i] >= MagLo:
            eq_sequence_number += 1

        last_eq = eq_sequence_number


    #.................................................................

     #   The large earthquakes were renumbered to start from 1 so need to correct for that

    first_eq    = int(0)
    second_eq   = int(last_eq) - 1

    number_of_eq_cycles = last_eq - first_eq
    
#     print('first_eq, last_eq, number_eqs, number_of_eq_cycles: ', first_eq, last_eq, number_eqs, number_of_eq_cycles)

    input_file.close()  # Put the file pointer back at top

    #.................................................................
    

    #   Now open the complete data file so that we can retrieve the small earthquakes    

    #   Count the number of small earthquakes in each cycle and store in array for binning
    #       and plotting in histogram

    number_small_eq_array   =   np.zeros(number_eqs)

    data_file = open("USGS_master.catalog", "r")     #  This is all the data and all the small events

    index_large_eq = -1             #   So the first large earthquake cycle will have index 0
    large_eq_flag = 'FALSE'

    for line in data_file:
        items   = line.strip().split()
        mag_query           = float(items[5])

        if mag_query < MagLo:
            date_small_quake    = items[0]
            time_small_quake    = items[1]

        if mag_query >= MagLo:
            large_eq_flag = 'TRUE'  #   Takes care of initial state where there is no initial large earthquake
            number_in_cycle =  0
            index_large_eq += 1
        if (mag_query < MagLo) and (mag_query >= min_mag) and (large_eq_flag == 'TRUE'):
            number_small_eq_array[index_large_eq] += 1
    
    data_file.close()               #   Close the data file

    #.................................................................

    print(' ')
    print('       Large EQ', '      Date and Time', '       Magnitude', '   Latitude', '    Longitude', '    Number Small EQs')
    print(' ')

    total_number_small_eqs = 0
    eq_limit = second_eq-first_eq +1  
    for i in range(first_eq,eq_limit):
        total_number_small_eqs += number_small_eq_array[i]
        if i+1 <10:
            blank_space = '         '
        if i+1 >=10:
            blank_space = '        '
        if i+1 >=100:
            blank_space = '       '
        print(blank_space, i+1, '     ', date_string[i] + ' ' + time_string[i], '     ', '%.2f'%mag[i], '     ', '%.3f'%(lat[i]), '    ', '%.3f'%lng[i],  \
                '          ',int(number_small_eq_array[i]))

    #.................................................................

    range_limit = len(lat)

    print_text_1 = '     Found ' + str(number_eqs) + ' earthquakes having M>' + str(MagLo) + ' around ' + Location
    print_text_2 = '     Occurring from: ' + date_string[0] + ' ' + time_string[0] 
    print_text_3 = '               thru: ' + date_string[number_eqs-1] + ' ' + time_string[number_eqs - 1]
    print(' ')
    print(print_text_1)
    print(' ')
    print(print_text_2)
    print(print_text_3)
    print('')
    print('     Total Number of Small Earthquakes: ', int(total_number_small_eqs))        
    print('')

   #.................................................................

   #
   #    Get the data on the circular region

    settings_params = get_settings()

    earthquake_depth    =   float(settings_params[2])
    Circle_Location     =   settings_params[3]
    Circle_Lat          =   float(settings_params[4])
    Circle_Lng          =   float(settings_params[5])
    Radius_float        =   float(settings_params[6])

#     mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = get_circle_catalog(Circle_Lat, Circle_Lng, Radius_float, MagLo)
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = read_circle_catalog()


   #    Reverse the magnitude array for the magnitudes of events in the circular region

    mag_array_reversed  =   list(reversed(mag_array))
    date_array_reversed =   list(reversed(date_array))
    time_array_reversed =   list(reversed(time_array))
    year_array_reversed =   list(reversed(year_array))
    depth_array_reversed=   list(reversed(depth_array))
    lat_array_reversed  =   list(reversed(lat_array))
    lng_array_reversed  =   list(reversed(lng_array))


   #    Now find the number of small events within the circle since last large event

    todays_count = 0    

    last_eq_mag     = '(No Data)'
    last_eq_date    = '(No Data)'
    last_eq_time    = '(No Data)'

   #.................................................................
   #
   #   This next bit finds the data on the last big earthquake

    mag_flag = 0
    for i in range(0,len(mag_array_reversed)):
        if float(mag_array_reversed[i]) >= MagLo and (mag_flag == 0) and (float(depth_array_reversed[i]) <= earthquake_depth):

            last_eq_mag         = str(mag_array_reversed[i])
            last_eq_date        = date_array_reversed[i]
            last_eq_time        = time_array_reversed[i]  

            mag_flag = 1
        if float(mag_array_reversed[i]) < MagLo and mag_flag == 0:
            todays_count += 1

   #.................................................................

#   num_bins = 100
    num_bins = 200

    #   Histogram the data

    number_small_eqs_excluding_last = np.zeros(number_eqs-1)

    for i in range(0,number_eqs-1):
        number_small_eqs_excluding_last[i] = number_small_eq_array[i]

    mean    =   mean_val(number_small_eqs_excluding_last)
    std_deviation, variance = std_var_val(number_small_eqs_excluding_last)

    mean_eqs        = int(mean)
    std_dev_eqs     = int(std_deviation)

    mean_small_EQs = '%.2f'%mean
    std_dev_small_EQs = '%.2f'%std_deviation  

    print('         Mean Number of Small Earthquakes: ', mean_small_EQs)
    print('     Standard Deviation Small Earthquakes: ', std_dev_small_EQs)
    print('')

    #.................................................................
    
   #.................................................................

    num_bins = 200

    #   Histogram the data

    number_small_eqs_excluding_last = []
    for i in range(0,index_large_eq):
        number_small_eqs_excluding_last.append(float(number_small_eq_array[i]))
        
    mean    =   mean_val(number_small_eqs_excluding_last)
    std_deviation, variance = std_var_val(number_small_eqs_excluding_last)

    mean_eqs = mean

    mean_small_EQs = '%.2f'%mean
    std_dev_small_EQs = '%.2f'%std_deviation  

    #.................................................................

    #   Bin the data

    todays_probability = 0.0

    n, bins = histogram(number_small_eqs_excluding_last, num_bins)
    
    cum_poisson = np.zeros(len(bins))   #   Cumulative Poisson distribution

    cum_prob = np.zeros(len(bins))

    for i in range(1,len(bins)):
        cum_prob[i] = cum_prob[i-1] +  n[i-1]
        cum_poisson[i] = 1.0 - math.exp(-bins[i]/float(mean_eqs))

    cum_poisson[:] = (cum_poisson[:]) * 100.0

    #   Calc cumulative probability

#     cum_prob[:] = cum_prob[:]/ float(last_eq)
    cum_prob[:] = cum_prob[:]/ float(sum(n))
    
    cum_prob[:] = cum_prob[:] *100.0

    #.................................................................

    for i in range(1, len(bins)):           #   Define today's temperature = Earthquake Potential Score (EPS)
        if todays_count >= bins[i]:
            todays_probability = cum_prob[i]

    #   Define the Temperature

    temperature = "{0:.1f}".format(todays_probability)+'%'
    eps_value = "{0:.1f}".format(todays_probability)

    #.................................................................

    #  Plot the data

    fig = plt.figure(figsize=(8, 6))        #   Define large figure and thermometer - 4 axes needed

    gs = gridspec.GridSpec(1,2,width_ratios=[14, 1], wspace = 0.2) 
    ax0 = plt.subplot(gs[0])

    #   Draw the bins

    ax0.hist(number_small_eqs_excluding_last, bins=num_bins, facecolor='green', edgecolor='black', alpha=0.5,lw=0.8, color= 'k')

    #   Get the axis limits

    ymin, ymax = ax0.get_ylim()
    xmin, xmax = ax0.get_xlim()

    plt.xlabel('Number of Small Earthquakes Between Large Earthquakes')
    plt.ylabel('Number of Earthquake Intervals')

    #.................................................................

    # Main plot

    City = Location.split('_')
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]
  
    todays_date          =  datetime.date.today().strftime("%B %d, %Y")
    SupTitle_text = 'EPS for M>' + str(MagLo) + ' Earthquakes near ' + City_Location + ' R<' + str(int(Radius_float)) + ' km'
    Title_text    = 'After M' + last_eq_mag + ' on ' + last_eq_date + ' at ' + last_eq_time
    
    plt.suptitle(SupTitle_text, fontsize=14)
    plt.title(Title_text, fontsize=12) 

    bins        = np.append(bins,bins[num_bins])
    cum_prob    = np.append(cum_prob, 100.0)
    cum_poisson = np.append(cum_poisson, 100.0)

    ax1 = ax0.twinx()

    plt.ylim(ymax = 100, ymin = 0)
    ymin, ymax = ax1.get_ylim()
    xmin, xmax = ax1.get_xlim()
    
    number_cdfs = 300
    cum_prob_random_mean, cum_prob_random_low, cum_prob_random_high, todays_stdev = \
            MCCalcMethods.calc_random_bands(cum_prob, number_small_eqs_excluding_last, num_bins, todays_count, number_cdfs)
            
    ax1.plot(bins,cum_prob, 'r-', zorder=10)
    
    ax1.plot(bins,cum_prob_random_low, '--', color='magenta', lw=0.7, zorder=10)
    ax1.plot(bins,cum_prob_random_high, '--', color='magenta', lw=0.7, zorder=10)
    
    ax1.plot(bins,cum_poisson, '--', color='blue', lw=0.7, zorder=10)
    
    #   -------------------------------------------------------------
    
    #   Write the legends on the plot

    text_x1          = (xmax-xmin)*0.40 + xmin
    text_y1          = (ymax-ymin) * 0.85 + ymin

    text_x2          = (xmax-xmin)*0.40 + xmin
    text_y2          = (ymax-ymin) * 0.80 + ymin
    
    count_string    = str(int(todays_count))
    text_string1 = 'Todays Small EQ Count M$\geq$' + str(completeness_mag)+ ':  ' + count_string 
    text_string2 = 'On:  ' + date_small_quake + '   at:  ' + time_small_quake
    plt.text(text_x1,text_y1,text_string1, fontsize=10)    
    plt.text(text_x2,text_y2,text_string2, fontsize=10)    

    text_x      = (xmax-xmin)*0.40 + xmin
    text_y      = (ymax-ymin) * 0.72 + ymin
    prob        = '%.1f'%(todays_probability)
    text_string = 'Todays EPS Value:  ' + prob + '% +/- ' + str(round(todays_stdev,1)) + '%'
    plt.text(text_x,text_y,text_string, fontsize=10)    
    
    #   -------------------------------------------------------------

    
    
    ax1.get_yaxis().set_ticks([0.,25, 50, 75, 100])
    ax1.plot([xmin,xmax],[50,50], 'b', ls='dotted')
    ax1.plot([xmin,xmax],[25,25], 'b', ls='dotted')
    ax1.plot([xmin,xmax],[75,75], 'b', ls='dotted')
    ax1.plot([todays_count,xmax],[todays_probability,todays_probability], 'r', ls='dashed', lw=1)
    x=[todays_count, todays_count]
    y=[0,todays_probability]
    ax1.plot(x,y, 'r', ls='dashed', lw=1)

    ax1.plot([todays_count], [todays_probability], 'ro', ms=8, zorder=20)
    ax1.plot([todays_count], [todays_probability], 'ko', fillstyle='none', lw = 0.8, ms=8, zorder=30)


    #.................................................................

    #   Thermometer

    ax3 = plt.subplot(gs[1])
    frame1 = plt.gca()
    plt.ylim([0,1])                         #   Show the y-axis labels
    plt.xlim([0,1])                         #   Set the x-axis limits  

    frame1.axes.get_xaxis().set_ticks([])   #   Hide the x-axis ticks and labels
    frame1.axes.get_yaxis().set_ticks([])

    ax4 = ax3.twinx()
    plt.ylim([0,100])                         #   Show the y-axis labels
    plt.xlim([0,1])

    ax4.get_yaxis().set_ticks([])
    x=[0.0,1.0]
    y=[todays_probability,todays_probability]
    ax4.fill_between(x,0,y, alpha=0.75, facecolor='red')
    ax4.plot(x,y, ls = 'solid', color='k', lw = 0.8)
    ax4.plot([0,1],[50,50], 'b', ls='dotted', lw=1)
    ax4.plot([0,1],[25,25], 'b', ls='dotted', lw=1)
    ax4.plot([0,1],[75,75], 'b', ls='dotted', lw=1)

     #.................................................................

    print('')
    print('Todays small earthquake count is: ', int(todays_count))

    print('Todays Earthquake Potential Score (Cumulative Probability) is: ', temperature + ' +/- ' + str(round(todays_stdev,1)) + '%')
    
    figure_name = './Data/' + Circle_Location + '_EPS.png'

    matplotlib.pyplot.savefig(figure_name,dpi=300)
    #matplotlib.pyplot.savefig('./Data/Earthquake-Potential-Score.jpg')
    matplotlib.pyplot.close('all')

    #plt.show()

    

    return (str(eps_value), str(int(mean_eqs)), str(int(std_dev_eqs)), str(int(todays_count)), last_eq_date, last_eq_mag, str(number_eqs))


    ######################################################################

def histogram_eps_region_polygon(NELat, NELng, SWLat, SWLng, MagLo, Location):

    print_data = 'TRUE'

    last_droplet_plot   =   'n'


    #   Open input file

    input_file = open("EQ_Working_Catalog.txt", "r")

    #   Find the number of lines in the file

    i=0
    for line in input_file:
        i       +=  1

    input_file.close()  # Put the file pointer back at top

    number_eqs = i

    input_file = open("EQ_Working_Catalog.txt", "r")

    # Create arrays of length i filled with zeros

    indx_string         =   ["" for x in range(number_eqs)]
    yrs                 =   zeros(number_eqs)
    lng                 =   zeros(number_eqs)
    lat                 =   zeros(number_eqs)
    mag                 =   zeros(number_eqs)
    dep                 =   zeros(number_eqs)

    time_string         =   ["" for x in range(number_eqs)]
    date_string         =   ["" for x in range(number_eqs)]

    # Bins for Number-magnitude plot

    min_mag = 3.0
    bin_diff= 0.1

    number_mag_bins     =   (MagLo - min_mag) / bin_diff + 1      #   Bin size = 0.1.  Assume min mag of interest is 3.0
    number_mag_bins     =   int(number_mag_bins)
    range_mag_bins      =   int(number_mag_bins)

    freq_mag_bins_pdf       =   zeros(number_mag_bins)
    freq_mag_bins_sdf       =   zeros(number_mag_bins)
    freq_mag_pdf_working    =   zeros(number_mag_bins)
    mag_array               =   zeros(number_mag_bins)  

    # Loop over lines and extract variables of interest

    i=-1
    eq_sequence_number = 0

    for line in input_file:
        line = line.strip()
        data = line.split()
        data_array = np.asarray(data)

        i       +=  1

        indx_string[i] =   data_array[0]
        date_string[i] =   data_array[1]
        time_string[i] =   data_array[2]

        yrs[i]     =    float(data_array[3])
        lng[i]     =    float(data_array[4])
        lat[i]     =    float(data_array[5])
        mag[i]     =    float(data_array[6])
        dep[i]     =    float(data_array[7])

    # Format and print the earthquake sequence numbers

        if mag[i] >= MagLo:
            eq_sequence_number += 1

        last_eq = eq_sequence_number


    #.................................................................

     #   The large earthquakes were renumbered to start from 1 so need to correct for that

    first_eq    = int(0)
    second_eq   = int(last_eq) - 1

    number_of_eq_cycles = last_eq - first_eq

    input_file.close()  # Put the file pointer back at top

    #.................................................................
    

    #   Now open the complete data file so that we can retrieve the small earthquakes    

    #   Count the number of small earthquakes in each cycle and store in array for binning
    #       and plotting in histogram

    number_small_eq_array   =   np.zeros(number_eqs)

    data_file = open("USGS_master.catalog", "r")     #  This is all the data and all the small events

    index_large_eq = -1             #   So the first large earthquake cycle will have index 0
    large_eq_flag = 'FALSE'

    for line in data_file:
        items   = line.strip().split()
        mag_query           = float(items[5])

        if mag_query < MagLo:
            date_small_quake    = items[0]
            time_small_quake    = items[1]

        if mag_query >= MagLo:
            large_eq_flag = 'TRUE'  #   Takes care of initial state where there is no initial large earthquake
            number_in_cycle =  0
            index_large_eq += 1
        if (mag_query < MagLo) and (large_eq_flag == 'TRUE'):
            number_small_eq_array[index_large_eq] += 1
    
    data_file.close()               #   Close the data file

    print(' ')
    print('       Large EQ', '      Date and Time', '       Magnitude', '   Latitude', '    Longitude', '    Number Small EQs')
    print(' ')

    total_number_small_eqs = 0
    eq_limit = second_eq-first_eq +1  
    for i in range(first_eq,eq_limit):
        total_number_small_eqs += number_small_eq_array[i]
        if i+1 <10:
            blank_space = '         '
        if i+1 >=10:
            blank_space = '        '
        if i+1 >=100:
            blank_space = '       '
        print(blank_space, i+1, '     ', date_string[i] + ' ' + time_string[i], '     ', '%.2f'%mag[i], '     ', '%.3f'%(lat[i]), '    ', '%.3f'%lng[i],  \
                '          ',int(number_small_eq_array[i]))

    #.................................................................

    range_limit = len(lat)

    print_text_1 = '     Found ' + str(number_eqs) + ' earthquakes having M>' + str(MagLo) + ' around ' + Location
    print_text_2 = '     Occurring from: ' + date_string[0] + ' ' + time_string[0] 
    print_text_3 = '               thru: ' + date_string[number_eqs-1] + ' ' + time_string[number_eqs - 1]
    print(' ')
    print(print_text_1)
    print(' ')
    print(print_text_2)
    print(print_text_3)
    print('')
    print('     Total Number of Small Earthquakes: ', int(total_number_small_eqs))        
    print('')

   #.................................................................
   #
   #    Get the data on the polygon region

    polygon_vertex_data = get_polygon_data(Location)

    mag_array, date_array, time_array, year_array = get_polygon_catalog(polygon_vertex_data,MagLo)

   #    Reverse the magnitude array for the magnitudes of events in the circular region

    mag_array_reversed  =   list(reversed(mag_array))
    date_array_reversed =   list(reversed(date_array))
    time_array_reversed =   list(reversed(time_array))
    year_array_reversed =   list(reversed(year_array))

   #    Now find the number of small events within the polygon since last large event

    todays_count = 0    

    mag_flag = 0
    for i in range(0,len(mag_array_reversed)):
        if float(mag_array_reversed[i]) >= MagLo and mag_flag == 0:
            last_eq_mag         = str(mag_array_reversed[i])
            last_eq_date        = date_array_reversed[i]
            last_eq_time        = time_array_reversed[i]  
            mag_flag = 1
        if float(mag_array_reversed[i]) < MagLo and mag_flag == 0:
            todays_count += 1

   #.................................................................

#   num_bins = 100
    num_bins = 200

    #   Histogram the data

    #   n[i] below is an array with the number of intervals in bin [i]
    #   bins[i] is an array with the location of the bin center
    #   patches[i] is an array with descriptions of each histogram rectangle
    #   set normed = 1 if you want the histogram to be a pdf

    #    n, bins, patches = plt.hist(number_small_eq_array, num_bins, facecolor='green', edgecolor='black',   alpha=0.5)

    number_small_eqs_excluding_last = np.zeros(number_eqs-1)

    for i in range(0,number_eqs-1):
        number_small_eqs_excluding_last[i] = number_small_eq_array[i]

    mean    =   mean_val(number_small_eqs_excluding_last)
    std_deviation, variance = std_var_val(number_small_eqs_excluding_last)

    mean_eqs = mean

    mean_small_EQs = '%.2f'%mean
    std_dev_small_EQs = '%.2f'%std_deviation  

    print('         Mean Number of Small Earthquakes: ', mean_small_EQs)
    print('     Standard Deviation Small Earthquakes: ', std_dev_small_EQs)

    #.................................................................

    #   Bin the data

    todays_probability = 0.0

    n, bins = histogram(number_small_eqs_excluding_last, num_bins)

    cum_poisson = np.zeros(len(bins))   #   Cumulative Poisson distribution

    cum_prob = np.zeros(len(bins))

    for i in range(1,len(bins)):
        cum_prob[i] = cum_prob[i-1] +  n[i-1]
        cum_poisson[i] = 1.0 - math.exp(-bins[i]/float(mean_eqs))

    cum_poisson[:] = (cum_poisson[:]) * 100.0

    #   Calc cumulative probability

    cum_prob[:] = cum_prob[:]/ float(last_eq)
    cum_prob[:] = cum_prob[:] *100.0

    tau_best, beta_best, sdev_tau, sdev_beta, sum_of_squares_low = weibullBetaFit(n, bins, cum_prob, mean_eqs)

    tau_string  = str(tau_best) + ' +/- ' + str(sdev_tau)
    beta_string = str(beta_best) + ' +/- ' + str(sdev_beta)

    print('')
    print(' Weibull fit data: ')
    print('')
    print(' Tau: ', tau_string)
    print('Beta: ', beta_string)
    print('')

    cum_weibull =   np.zeros(len(bins)+1)

    for i in range(1,len(bins)):
        cum_weibull[i] = 1.0 - math.exp(-((bins[i]/tau_best)**beta_best))

    cum_weibull[:] = cum_weibull[:] *100.0
    

    #.................................................................

    for i in range(1, len(bins)):           #   Define today's temperature = Earthquake Potential Score (EPS)
        if todays_count >= bins[i]:
            todays_probability = cum_prob[i]

    #   Define the Temperature

    temperature = "{0:.1f}".format(todays_probability)+'%'
    eps_value = "{0:.1f}".format(todays_probability)

    #.................................................................

    #  Plot the data

    fig = plt.figure(figsize=(8, 6))        #   Define large figure and thermometer - 4 axes needed

    gs = gridspec.GridSpec(1,2,width_ratios=[14, 1], wspace = 0.2) 
    ax0 = plt.subplot(gs[0])

    #   Draw the bins

    ax0.hist(number_small_eq_array, num_bins, facecolor='green', edgecolor='black',   alpha=0.5)

    #   Get the axis limits

    ymin, ymax = ax0.get_ylim()
    xmin, xmax = ax0.get_xlim()

    Polygon_Location = polygon_vertex_data[0]
    Polygon_Location_actual = Polygon_Location.split('-')

    todays_date          =  datetime.date.today().strftime("%B %d, %Y")
#    SupTitle_text = 'EPS for M>' + str(MagLo) + ' Earthquakes within ' + Polygon_Location_actual[0] + ' on ' + todays_date
    SupTitle_text = 'EPS for M>' + str(MagLo) + ' Earthquakes within ' + Polygon_Location_actual[0]
    Title_text    = 'After M' + last_eq_mag + ' on ' + last_eq_date + ' at ' + last_eq_time

    plt.xlabel('Number of Small Earthquakes Between Large Earthquakes')
    plt.ylabel('Number of Earthquake Intervals')

    #   Write the legends on the plot

    text_x1          = (xmax-xmin)*0.40 + xmin
    text_y1          = (ymax-ymin) * 0.90 + ymin

    text_x2          = (xmax-xmin)*0.40 + xmin
    text_y2          = (ymax-ymin) * 0.85 + ymin

    count_string    = str(int(todays_count))
    text_string1 = 'Todays Small EQ Count:  ' + count_string 
    text_string2 = 'On:  ' + date_small_quake + '   at:  ' + time_small_quake
    plt.text(text_x1,text_y1,text_string1, fontsize=12)    
    plt.text(text_x2,text_y2,text_string2, fontsize=12)    

    text_x      = (xmax-xmin)*0.40 + xmin
    text_y      = (ymax-ymin) * 0.77 + ymin
    prob        = '%.1f'%(todays_probability)
    text_string = 'Todays EPS Value:  ' + prob +'%'
    plt.text(text_x,text_y,text_string, fontsize=12)    

    #.................................................................

    # Main plot

    plt.suptitle(SupTitle_text, fontsize=14)
    plt.title(Title_text, fontsize=12) 

    bins        = np.append(bins,bins[num_bins])
    cum_prob    = np.append(cum_prob, 100.0)
    cum_poisson = np.append(cum_poisson, 100.0)

    ax1 = ax0.twinx()
    ax1.plot(bins,cum_prob, 'r-')
    plt.ylim(ymax = 100, ymin = 0)
    ymin, ymax = ax1.get_ylim()

    ax1.get_yaxis().set_ticks([0.,25, 50, 75, 100])
    ax1.plot([xmin,xmax],[50,50], 'b', ls='dotted')
    ax1.plot([xmin,xmax],[25,25], 'b', ls='dotted')
    ax1.plot([xmin,xmax],[75,75], 'b', ls='dotted')
    ax1.plot([todays_count,xmax],[todays_probability,todays_probability], 'r', ls='dashed', lw=1)
    x=[todays_count, todays_count]
    y=[0,todays_probability]
    ax1.plot(x,y, 'r', ls='dashed', lw=1)
    ax1.plot([todays_count], [todays_probability], 'ro', ms=8)
    ax1.plot([todays_count], [todays_probability], 'ko', fillstyle='none', lw = 0.8, ms=8)
    x=[mean_small_EQs,mean_small_EQs]
    y=[0,100]
    ax1.plot(x,y, 'k', ls='dotted')


    #.................................................................

    #   Thermometer

    ax3 = plt.subplot(gs[1])
    frame1 = plt.gca()
    plt.ylim([0,1])                         #   Show the y-axis labels
    plt.xlim([0,1])                         #   Set the x-axis limits  

    frame1.axes.get_xaxis().set_ticks([])   #   Hide the x-axis ticks and labels
    frame1.axes.get_yaxis().set_ticks([])

    ax4 = ax3.twinx()
    plt.ylim([0,100])                         #   Show the y-axis labels
    plt.xlim([0,1])

    ax4.get_yaxis().set_ticks([])
#    ax4.set_ylabel('Seismic "Temperature" = Current Cumulative Probability (%)', rotation=90)
    x=[0.0,1.0]
    y=[todays_probability,todays_probability]
    ax4.fill_between(x,0,y, alpha=0.75, facecolor='red')
    ax4.plot(x,y, ls = 'solid', color='k', lw = 0.8)
    ax4.plot([0,1],[50,50], 'b', ls='dotted', lw=1)
    ax4.plot([0,1],[25,25], 'b', ls='dotted', lw=1)
    ax4.plot([0,1],[75,75], 'b', ls='dotted', lw=1)

    #.................................................................

    print('')
    print('Todays small earthquake count is: ', int(todays_count))

    print('Todays Earthquake Potential Score (Cumulative Probability) is: ', temperature)
 
    matplotlib.pyplot.savefig('Earthquake-Potential-Score.png',dpi=300)

    plt.show()

    return (str(eps_value), str(mean_small_EQs), str(std_dev_small_EQs), str(int(todays_count)), last_eq_date, last_eq_mag, str(number_eqs))

    ######################################################################

def map_epicenters(NELat, NELng, SWLat, SWLng, MagLo, Location):

    #   -----------------------------------------
    #   Define plot map
    
    dateline_crossing = False
    
    left_long   =   SWLng
    right_long  =   NELng
    bottom_lat  =   SWLat
    top_lat     =   NELat
    
    longitude_labels = [left_long, right_long]
    longitude_labels_dateline = [left_long, 180, right_long, 360]   #   If the map crosses the dateline
    
    central_long_value = 0
    if dateline_crossing:
        central_long_value = 180
        
    ax = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_long_value))
    ax.set_extent([left_long, right_long, bottom_lat, top_lat])

    # Create a feature for States/Admin 1 regions at 1:50m from Natural Earth
    states_provinces = cfeature.NaturalEarthFeature(
        category='cultural',
        name='admin_1_states_provinces_lines',
        scale='50m',
        facecolor='none')
        
    land_10m = cfeature.NaturalEarthFeature('physical', 'land', '10m',
                                        edgecolor='face',
                                        facecolor='coral')
                                        
                                        
    ocean_10m_0 = cfeature.NaturalEarthFeature('physical', 'bathymetry_L_0', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#89CFF0',
                                        alpha = 0.5)
                                        
                                        
    ocean_10m_200 = cfeature.NaturalEarthFeature('physical', 'bathymetry_K_200', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#73C2FB',
                                        alpha = 0.5)
                                        
    ocean_10m_1000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_J_1000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#57A0D3',
                                        alpha = 0.5)
    
    ocean_10m_2000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_I_2000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#6593F5',
                                        alpha = 0.5)
                                        
    ocean_10m_3000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_H_3000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#0080FF',
                                        alpha = 0.3)
                                        
    ocean_10m_4000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_G_4000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#1034A6',
                                        alpha = 0.5)
                                        
    ocean_10m_6000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_E_6000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#000080',
                                        alpha = 0.5)
                                        
    ocean_10m_8000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_C_8000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#111E6C',
                                        alpha = 0.5)
                                        
    ocean_10m_10000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_A_10000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#1D2951',
                                        alpha = 0.5)
                                        
                                        
    lakes_10m = cfeature.NaturalEarthFeature('physical', 'lakes', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
    rivers_and_lakes = cfeature.NaturalEarthFeature('physical', 'rivers_lakes_centerlines', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
                                        
    ax.add_feature(ocean_10m_0)
    ax.add_feature(ocean_10m_200)
    ax.add_feature(ocean_10m_1000)
    ax.add_feature(ocean_10m_2000)
    ax.add_feature(ocean_10m_3000)
    ax.add_feature(ocean_10m_4000)
    ax.add_feature(ocean_10m_6000)
    ax.add_feature(ocean_10m_8000)                                        


#     ax.add_feature(cfeature.OCEAN)                  #   perhaps this is low resolution also 
    ax.add_feature(cartopy.feature.COASTLINE)
    ax.add_feature(cfeature.BORDERS, lw = 0.25)
    ax.add_feature(cfeature.LAKES, alpha=0.95)
#     ax.add_feature(cfeature.OCEAN, color='blue', alpha=0.95)
    ax.add_feature(cfeature.RIVERS, lw = 0.5)
    ax.add_feature(cfeature.STATES, edgecolor='black',linewidth= 0.25)
    ax.coastlines(resolution='10m', edgecolor='black', linewidth=0.25)
    
    stamen_terrain = cimgt.Stamen('terrain-background')

#   The second argument below is the Zoom level.  If you get a download warning, try decreasing this number
    ax.add_image(stamen_terrain, 4)
    
 
    #   Setting central_longitude = 180 here puts the dateline at 0 degrees
    
    if dateline_crossing == False:
        gl = ax.gridlines(crs = ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.4, color='black', alpha=0.5, linestyle='dotted')
                   
    if dateline_crossing == True:
        gl = ax.gridlines(xlocs=longitude_labels_dateline, draw_labels=True,
                   linewidth=0.4, color='black', alpha=0.5, linestyle='dotted')

    gl.top_labels = False
    gl.right_labels = False
    
    gl.xlines = True
    gl.ylines = True
    
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
#     
    #   -----------------------------------------
    #   Put some lines and other image elements on the map here
 
    settings_params = get_settings()

    region_type = settings_params[0]

    #   -------------------------------------------

    if region_type == 'Circle':
        Polygon_Location = 'None'

        Circle_Location = settings_params[3]
        earthquake_depth = float(settings_params[2])

        if Circle_Location != 'None':
            earthquake_depth = float(settings_params[2])
            CircleCenterLat = float(settings_params[4])
            CircleCenterLng = float(settings_params[5])
            CircleRadius    = float(settings_params[6])

         #   -------------------------------------------

    if region_type == 'Polygon':
        Circle_Location = 'None'

        number_polygon_vertices = (len(settings_params)-4)/2

        Polygon_Location = settings_params[3]
        earthquake_depth = float(settings_params[2])

        if Polygon_Location != 'None':
            earthquake_depth = float(settings_params[2])

        x_poly = []
        y_poly = []

        for j in range(0,number_polygon_vertices):
            y_poly.append(settings_params[4+2*j])
            x_poly.append(settings_params[5+2*j])

    #   Close the polygon

        y_poly.append(settings_params[4])
        x_poly.append(settings_params[5])

        for i in range(0,len(x_poly)):
            x_poly[i] = float(x_poly[i])
            y_poly[i] = float(y_poly[i])

  
    #   -------------------------------------------


    #   Open input file and find the number of lines in the file

    input_file = open("EQ_Working_Catalog.txt", "r")

    i=0
    for line in input_file:
        i       +=  1

    input_file.close()  # Put the file pointer back at top

    number_eqs=i
    
    #   Open input file again

    input_file = open("EQ_Working_Catalog.txt", "r")

    # Loop over lines and extract variables of interest

    # Create arrays of length i filled with zeros

    indx_string         =   ["" for x in range(i)]
    yrs                 =   zeros(i)
    lng                 =   zeros(i)
    lat                 =   zeros(i)
    mag                 =   zeros(i)
    dep                 =   zeros(i)
    time_string         =   ["" for x in range(i)]
    date_string         =   ["" for x in range(i)]

    # Loop over lines and extract variables of interest

    i=-1
    for line in input_file:
        line = line.strip()
        data = line.split()
        data_array = np.asarray(data)

        i       +=  1

        indx_string[i] =   data_array[0]
        date_string[i] =   data_array[1]
        time_string[i] =   data_array[2]

        yrs[i]     =    float(data_array[3])
        lng[i]     =    float(data_array[4])
        lat[i]     =    float(data_array[5])
        mag[i]     =    float(data_array[6])
        dep[i]     =    float(data_array[7])

    input_file.close()  # Put the file pointer back at top

    z_limit = len(lat)
    range_limit = z_limit - 1

    print_text_1 = '     Found ' + str(number_eqs) + ' earthquakes having M>' + str(MagLo) + ' around ' + Location
    print_text_2 = '     Occurring from: ' + date_string[0] + ' ' + time_string[0] 
    print_text_3 = '               thru: ' + date_string[number_eqs-1] + ' ' + time_string[number_eqs - 1]
    print_text_4 = '     at depths < ' + str(settings_params[2]) + ' km'


    #.................................................................

    for z in range(z_limit):
        x,y = (lng,lat)

    #   -----------------------
        if mag[z] >= 5.0:
            mark_size = 3
        if mag[z] >= 5.5:
            mark_size = 4
        if mag[z] >= 6:
            mark_size = 6
        if mag[z] >= 6.5:
            mark_size = 8
        if mag[z] >= 7:
            mark_size = 10
        if mag[z] >= 7.5:
            mark_size = 12
        if mag[z] >= 8.0:
            mark_size = 14
        if mag[z] >= 8.5:
            mark_size = 16
    #   ----------------------
            
    #   m.plot(x[z], y[z], "ro", mfc='none', mec='r', markeredgewidth=2.0, ms=mark_size[z])
        ax.plot(x[z], y[z], "ro", ms=mark_size)
        ax.plot(x[z], y[z], "o", ms=mark_size, fillstyle='none', color='k', lw=0.4)
        

    if (Circle_Location != 'None'):
        x_circle_dg, y_circle_dg = MCUtilities.createCircleAroundWithRadius(CircleCenterLat, CircleCenterLng, CircleRadius)
        
        ax.plot(x_circle_dg, y_circle_dg, "b-", lw=1.3)

    if (Polygon_Location != 'None'):
        ax.plot(x_poly, y_poly, "b-", lw=1.6)

    #   ------------------------------------------------------

    sfv     =   (NELat-SWLat)/12.0
    sfh     =   (NELng-SWLng)/16.0

    sfh     =   sfh * 0.9
    sfht    =   sfh * 1.1  # move the text over a bit more
    
    llcrnrlat = SWLat
    llcrnlon  = SWLng
    urcrnlat  = NELat
    urcrnrlon = NELng
    
    lat=[llcrnrlat - 0.30*sfv, llcrnrlat + 0.25*sfv,llcrnrlat + 0.80*sfv, llcrnrlat + 1.30*sfv, llcrnrlat + 1.80*sfv, llcrnrlat + 2.40*sfv, llcrnrlat + 3.1*sfv, llcrnrlat + 3.95*sfv]
    lng=[urcrnrlon + 1.2*sfht, urcrnrlon + 1.2*sfht, urcrnrlon + 1.2*sfht, urcrnrlon + 1.2*sfht, urcrnrlon + 1.2*sfht, urcrnrlon + 1.2*sfht, urcrnrlon + 1.2*sfht, urcrnrlon + 1.2*sfht]
    x,y = (lng,lat)

    latc=[llcrnrlat - 0.25*sfv, llcrnrlat + 0.30*sfv,llcrnrlat + 0.85*sfv, llcrnrlat + 1.375*sfv, llcrnrlat + 1.90*sfv, llcrnrlat + 2.50*sfv, llcrnrlat + 3.2*sfv, llcrnrlat + 4.0*sfv]
    lngc=[urcrnrlon + 0.72*sfh, urcrnrlon + 0.72*sfh, urcrnrlon + 0.73*sfh, urcrnrlon + 0.74*sfh, urcrnrlon + 0.76*sfh, urcrnrlon + 0.78*sfh, urcrnrlon + 0.80*sfh, urcrnrlon + 0.80*sfh]
    xc,yc = (lngc,latc)

    mag_value=['5.0+','5.5+','6+','6.5+','7+','7.5+', '8+', '8.5+']

    mark_size = [3, 4, 6, 8, 10, 12, 14, 16]

    for z in range(8):
        plt.text(x[z],y[z],mag_value[z], fontsize=10,)
        ax.plot(xc[z], yc[z], "ro", ms=mark_size[z], clip_on=False)
        ax.plot(xc[z], yc[z], "ro", ms=mark_size[z], clip_on=False, fillstyle='none', markeredgecolor='k', lw=0.4)

    City = Location.split('_')
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]

    if region_type == 'Circle':

        if Circle_Location == 'None':
            SupTitle_text = 'Earthquake Epicenters for M>' + str(MagLo) + ' near ' + Location

        if Circle_Location != 'None':
            Circle_Location_actual = Circle_Location.split('-')
            SupTitle_text = 'Earthquakes M>' + str(MagLo) + ' near ' + City_Location

    if region_type == 'Polygon':

        if Polygon_Location == 'None':
            SupTitle_text = 'Earthquake Epicenters for M>' + str(MagLo) + ' in ' + Location + ' at Depth < ' + str(earthquake_depth) +  'km'

        if Polygon_Location != 'None':
            Polygon_Location_actual = Polygon_Location.split('-')
            SupTitle_text = 'Earthquakes M>' + str(MagLo) + ' in ' + Location + ' at Depth < ' + str(earthquake_depth) + ' km'

    plt.suptitle(SupTitle_text, fontsize=14)

    Title_text = 'From: ' + date_string[0] + ' To: ' + date_string[range_limit] + ' R<' + str(int(CircleRadius)) \
            + ' km, D<'+ str(int(earthquake_depth)) +' km' 
    plt.title(Title_text, fontsize=12)
    
    figure_name = './Data/' + Circle_Location + '_Seismicity.png'
    plt.savefig(figure_name, dpi=300)

    plt.close('all')

    #plt.show()

    return None

    ######################################################################
    
def map_epicenters_local(NELat_local, NELng_local, SWLat_local, SWLng_local, completeness_mag, MagLo, Location):

    #   -----------------------------------------
    #   Define plot map
    
    dateline_crossing = False
    
    left_long   =   SWLng_local
    right_long  =   NELng_local
    bottom_lat  =   SWLat_local
    top_lat     =   NELat_local
    
    longitude_labels = [left_long, right_long]
    longitude_labels_dateline = [left_long, 180, right_long, 360]   #   If the map crosses the dateline
    
    central_long_value = 0
    if dateline_crossing:
        central_long_value = 180
        
    ax = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_long_value))
    ax.set_extent([left_long, right_long, bottom_lat, top_lat])

    # Create a feature for States/Admin 1 regions at 1:50m from Natural Earth
    states_provinces = cfeature.NaturalEarthFeature(
        category='cultural',
        name='admin_1_states_provinces_lines',
        scale='50m',
        facecolor='none')
        
    land_10m = cfeature.NaturalEarthFeature('physical', 'land', '10m',
                                        edgecolor='face',
                                        facecolor='coral')
                                        
    ocean_10m_0 = cfeature.NaturalEarthFeature('physical', 'bathymetry_L_0', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#89CFF0',
                                        alpha = 0.5)
                                        
    ocean_10m_200 = cfeature.NaturalEarthFeature('physical', 'bathymetry_K_200', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#73C2FB',
                                        alpha = 0.5)
                                        
    ocean_10m_1000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_J_1000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#57A0D3',
                                        alpha = 0.5)
    
    ocean_10m_2000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_I_2000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#6593F5',
                                        alpha = 0.5)
                                        
    ocean_10m_3000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_H_3000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#0080FF',
                                        alpha = 0.3)
                                        
    ocean_10m_4000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_G_4000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#1034A6',
                                        alpha = 0.5)
                                        
    ocean_10m_6000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_E_6000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#000080',
                                        alpha = 0.3)
                                        
    ocean_10m_8000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_C_8000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#111E6C',
                                        alpha = 0.5)
                                        
    ocean_10m_10000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_A_10000', '10m',
#                                        edgecolor='aqua',
                                        facecolor='#1D2951',
                                        alpha = 0.5)
                                        
                                        
    lakes_10m = cfeature.NaturalEarthFeature('physical', 'lakes', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
    rivers_and_lakes = cfeature.NaturalEarthFeature('physical', 'rivers_lakes_centerlines', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
#     ocean_all = cfeature.NaturalEarthFeature('physical', 'bathymetry_all', '10m',
# #                                        edgecolor='aqua',
#                                         facecolor='aqua',
#                                         alpha = 0.3)
                                        
    ax.add_feature(ocean_10m_0)
    ax.add_feature(ocean_10m_200)
    ax.add_feature(ocean_10m_1000)
    ax.add_feature(ocean_10m_2000)
    ax.add_feature(ocean_10m_3000)
    ax.add_feature(ocean_10m_4000)
    ax.add_feature(ocean_10m_6000)
    ax.add_feature(ocean_10m_8000)           

#     ax.add_feature(cfeature.OCEAN)                  #   perhaps this is low resolution also 
    ax.add_feature(cartopy.feature.COASTLINE)
    ax.add_feature(cfeature.BORDERS, linewidth=0.5, lw = 0.5)
    ax.add_feature(cfeature.LAKES, alpha=0.95)
    ax.add_feature(cartopy.feature.RIVERS, linewidth=0.5)
    ax.add_feature(cfeature.STATES, edgecolor='black',linewidth= 0.5)
    ax.coastlines(resolution='10m', color='black', linewidth=0.5)
    
    stamen_terrain = cimgt.Stamen('terrain-background')

#   The second argument below is the Zoom level.  If you get a download warning, try decreasing this number
    ax.add_image(stamen_terrain, 6)
    
    #   Setting central_longitude = 180 here puts the dateline at 0 degrees
    
    if dateline_crossing == False:
        gl = ax.gridlines(crs = ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.4, color='black', alpha=0.5, linestyle='dotted')
                   
    if dateline_crossing == True:
        gl = ax.gridlines(xlocs=longitude_labels_dateline, draw_labels=True,
                   linewidth=0.4, color='black', alpha=0.5, linestyle='dotted')

    gl.top_labels = False
    gl.right_labels = False
    
    gl.xlines = True
    gl.ylines = True
    
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
#     
    x_poly=[170,-170]
    y_poly=[55,55]
    
#     

    #   -----------------------------------------
    #   Put some lines and other image elements on the map here

    settings_params = get_settings()

    region_type = settings_params[0]

    #   -------------------------------------------

    if region_type == 'Circle':
        Polygon_Location = 'None'

        Circle_Location = settings_params[3]
        earthquake_depth = float(settings_params[2])

        if Circle_Location != 'None':
            earthquake_depth = float(settings_params[2])
            CircleCenterLat = float(settings_params[4])
            CircleCenterLng = float(settings_params[5])
            CircleRadius    = float(settings_params[6])

         #   -------------------------------------------

    if region_type == 'Polygon':
        Circle_Location = 'None'

        number_polygon_vertices = (len(settings_params)-4)/2

        Polygon_Location = settings_params[3]
        earthquake_depth = float(settings_params[2])

        if Polygon_Location != 'None':
            earthquake_depth = float(settings_params[2])

        x_poly = []
        y_poly = []

        for j in range(0,number_polygon_vertices):
            y_poly.append(settings_params[4+2*j])
            x_poly.append(settings_params[5+2*j])

    #   Close the polygon

        y_poly.append(settings_params[4])
        x_poly.append(settings_params[5])

        for i in range(0,len(x_poly)):
            x_poly[i] = float(x_poly[i])
            y_poly[i] = float(y_poly[i])

  
   #   -------------------------------------------
   #
   #    Re-download the data in the circular region for the local seismicity plot

    settings_params = get_settings()

    earthquake_depth    =   float(settings_params[2])
    Circle_Location     =   settings_params[3]
    Circle_Lat          =   float(settings_params[4])
    Circle_Lng          =   float(settings_params[5])
    Radius_float        =   float(settings_params[6])

#     mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = get_circle_catalog(Circle_Lat, Circle_Lng, Radius_float, MagLo)
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = read_circle_catalog()

   #    Reverse the magnitude array for the magnitudes of events in the circular region

    mag_array_reversed  =   list(reversed(mag_array))
    date_array_reversed =   list(reversed(date_array))
    time_array_reversed =   list(reversed(time_array))
    year_array_reversed =   list(reversed(year_array))
    depth_array_reversed=   list(reversed(depth_array))
    lat_array_reversed  =   list(reversed(lat_array))
    lng_array_reversed  =   list(reversed(lng_array))


   #    Now find the number of small events within the circle since last large event

    todays_count = 0    

    last_eq_mag     = '(No Data)'
    last_eq_date    = '(No Data)'
    last_eq_time    = '(No Data)'
    last_eq_year    = '(No Data)'
    last_eq_lat     = '(No Data)'
    last_eq_lng     = '(No Data)'
    last_eq_depth   = '(No Data)'

   #.................................................................
   #
   #   This next bit finds the data on the last big earthquake

    mag_flag = 0
    for i in range(0,len(mag_array_reversed)):
        if float(mag_array_reversed[i]) >= MagLo and (mag_flag == 0) and (float(depth_array_reversed[i]) <= earthquake_depth):

            last_eq_mag         = str(mag_array_reversed[i])
            last_eq_date        = date_array_reversed[i]
            last_eq_time        = time_array_reversed[i]  
            last_eq_year        = year_array_reversed[i]
            last_eq_lat         = lat_array_reversed[i]
            last_eq_lng         = lng_array_reversed[i]
            last_eq_depth       = depth_array_reversed[i]

            mag_flag = 1
        if float(mag_array_reversed[i]) < MagLo and mag_flag == 0:
            todays_count += 1

   #.................................................................
   #
   #    Write catalog of most recent small earthquakes in the circle

    working_file_local = open("EQ_Working_Catalog_Local.txt", "w")    

    for i in range(0,todays_count):
        working_file_local.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n" % \
                (i+1, date_array_reversed[i], time_array_reversed[i], year_array_reversed[i], lng_array_reversed[i], \
                lat_array_reversed[i], mag_array_reversed[i], depth_array_reversed[i]))

    if (last_eq_mag != '(No Data)'):
        working_file_local.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t\n" % (i+2, last_eq_date, last_eq_time, last_eq_year, \
                last_eq_lng, last_eq_lat, last_eq_mag, last_eq_depth))

    working_file_local.close()


   #.................................................................



    #   Open input file and find the number of lines in the file

    input_file = open("EQ_Working_Catalog_Local.txt", "r")

    i=0
    for line in input_file:
        i       +=  1

    input_file.close()  # Put the file pointer back at top

    number_eqs=i

    #   Open input file again

    input_file = open("EQ_Working_Catalog_Local.txt", "r")

    # Loop over lines and extract variables of interest

    # Create arrays of length i filled with zeros

    indx_string         =   ["" for x in range(i)]
    yrs                 =   zeros(i)
    lng                 =   zeros(i)
    lat                 =   zeros(i)
    mag                 =   zeros(i)
    dep                 =   zeros(i)
    time_string         =   ["" for x in range(i)]
    date_string         =   ["" for x in range(i)]

    # Loop over lines and extract variables of interest

    i=-1
    for line in input_file:
        line = line.strip()
        data = line.split()
        data_array = np.asarray(data)

        i       +=  1

        indx_string[i] =   data_array[0]
        date_string[i] =   data_array[1]
        time_string[i] =   data_array[2]

        yrs[i]     =    float(data_array[3])
        lng[i]     =    float(data_array[4])
        lat[i]     =    float(data_array[5])
        mag[i]     =    float(data_array[6])
        dep[i]     =    float(data_array[7])

    input_file.close()  # Put the file pointer back at top

    z_limit = len(lat)
    range_limit = z_limit - 1

    if z_limit > 0:
        print_text_1 = '     Found ' + str(number_eqs) + ' earthquakes having M>' + str(MagLo) + ' around ' + Location
        print_text_2 = '     Occurring from: ' + date_string[0] + ' ' + time_string[0] 
        print_text_3 = '               thru: ' + date_string[number_eqs-1] + ' ' + time_string[number_eqs - 1]
        print_text_4 = '     at depths < ' + str(settings_params[2]) + ' km'

    #.................................................................

    color_start =   0.0
    color_stop  =   1.0

    #   z_limit is the number of points

    cm_subsection = linspace(color_start, color_stop, z_limit) 
    colors = [ cm.rainbow(x) for x in cm_subsection ]

    mag_diff = 0.1*(float(MagLo) - float(completeness_mag))

    mag1 = completeness_mag
    mag2 = completeness_mag + 1.0*mag_diff
    mag3 = completeness_mag + 2.0*mag_diff
    mag4 = completeness_mag + 3.0*mag_diff
    mag5 = completeness_mag + 4.0*mag_diff
    mag6 = completeness_mag + 5.0*mag_diff
    mag7 = completeness_mag + 6.0*mag_diff
    mag8 = completeness_mag + 7.0*mag_diff
    mag9 = completeness_mag + 8.0*mag_diff
    mag10= completeness_mag + 9.0*mag_diff
    mag11= MagLo

    if z_limit >0:

        for z in range(z_limit):
            x,y = (lng,lat)

    #   -----------------------

            w = z_limit-z-1

            if mag[w] >= mag1:
                mark_size = 4
            if mag[w] >= mag2:
                mark_size = 5
            if mag[w] >= mag3:
                mark_size = 6
            if mag[w] >= mag4:
                mark_size = 7
            if mag[w] >= mag5:
                mark_size = 8
            if mag[w] >= mag6:
                mark_size = 9
            if mag[w] >= mag7:
                mark_size = 10
            if mag[w] >= mag8:
                mark_size = 11
            if mag[w] >= mag9:
                mark_size = 12
            if mag[w] >= mag10:
                mark_size = 13
            if mag[w] >= mag11:
                mark_size = 20
    #   ----------------------
     
            ax.plot(x[w], y[w], "o", ms=mark_size, color=colors[z])
            ax.plot(x[w], y[w], "o", ms=mark_size, fillstyle='none', color='k', lw=0.4)
            

    if (Circle_Location != 'None'):
#        x_circle_dg, y_circle_dg = draw_big_circle(CircleCenterLat, CircleCenterLng, CircleRadius)
        x_circle_dg, y_circle_dg = MCUtilities.createCircleAroundWithRadius(CircleCenterLat, CircleCenterLng, CircleRadius)
        
        ax.plot(x_circle_dg, y_circle_dg, "b-", lw=1.3)

    if (Polygon_Location != 'None'):
        ax.plot(x_poly, y_poly, "b-", lw=1.6)


    #   ------------------------------------------------------

    sfv     =   (NELat_local-SWLat_local)/12.0
    sfh     =   (NELng_local-SWLng_local)/16.0

    sfh     =   sfh * 0.9
    sfht    =   sfh * 1.35  # move the text over a bit more
    
    llcrnrlat = SWLat_local
    llcrnlon  = SWLng_local
    urcrnlat  = NELat_local
    urcrnrlon = NELng_local

    lat=[llcrnrlat, llcrnrlat + 0.775*sfv]
    lng=[urcrnrlon + 1.25*sfht, urcrnrlon + 1.25*sfht]

    x,y = (lng,lat)

    latc=[llcrnrlat + 0.15*sfv, llcrnrlat + 0.9*sfv]
    lngc=[urcrnrlon + 0.85*sfh, urcrnrlon + 0.85*sfh]
    
    xc,yc = (lngc,latc)

    mag_value=[str(completeness_mag),str(MagLo)+'+']

    mark_size = [4, 20]

    for z in range(2):
        plt.text(x[z],y[z],mag_value[z], fontsize=10)
        ax.plot(xc[z], yc[z], "ro", ms=mark_size[z], clip_on=False)
        ax.plot(xc[z], yc[z], "ro", ms=mark_size[z], clip_on=False, fillstyle='none', markeredgecolor='k', lw=0.6)

    City = Location.split('_')
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]

    if region_type == 'Circle':

        if Circle_Location == 'None':
            SupTitle_text = 'Earthquake Epicenters for M>' + str(MagLo) + ' near ' + Location

        if Circle_Location != 'None':
            Circle_Location_actual = Circle_Location.split('-')
            SupTitle_text = 'Small Earthquakes M>' + str(completeness_mag) + ' near ' + City_Location 

    if region_type == 'Polygon':

        if Polygon_Location == 'None':
            SupTitle_text = 'Earthquake Epicenters for M>' + str(MagLo) + ' in ' + Location + ' at Depth < ' + str(earthquake_depth) +  'km'

        if Polygon_Location != 'None':
            Polygon_Location_actual = Polygon_Location.split('-')
            SupTitle_text = 'Earthquakes M>' + str(completeness_mag) + ' in ' + Location + ' at Depth < ' + str(earthquake_depth) + ' km'

    plt.suptitle(SupTitle_text, fontsize=14)

    if z_limit > 0:
        Title_text = 'Since M'+ str(mag[range_limit]) + ' on ' + date_string[range_limit] + ' ' + \
                ' To: ' + date_string[0] + ' R<'+ str(int(CircleRadius)) + ' km, D<'+ str(int(earthquake_depth)) +' km'
        plt.title(Title_text, fontsize=12)

    figure_name = './Data/' + Circle_Location + '_Seismicity_Local.png'
    plt.savefig(figure_name,dpi=300)

    plt.close('all')

    return None

    #.................................................................
    
def get_circle_data(Location):

#   Read Circle_Location and data from "Settings_File.txt"

    settings_params = get_settings()
    default_settings_params = settings_params

    region_type = settings_params[0]
    completeness_mag    =   float(settings_params[1])
    earthquake_depth    =   float(settings_params[2])

    if region_type == 'Circle':     #   If still a circle, proceed
        Circle_Location     =   settings_params[3]
        small_radius        =   float(settings_params[6])

    if region_type != 'Circle':     #   If not a circle, reset settings_params to null
        Circle_Location     =   'None'
        Circle_Lat          =   0.0
        Circle_Lng          =   0.0
        Radius_float        =   0.0

        settings_params     =   []
        settings_params.append(region_type)
        settings_params.append(completeness_mag)
        settings_params.append(earthquake_depth)
        settings_params.append(Circle_Location)
        settings_params.append(Circle_Lat)
        settings_params.append(Circle_Lng)
        settings_params.append(Radius_float)

   #
   #    Get the data for the circle: Read pre-defined locations file
   #

    input_file = open("city_locations.txt", "r")
    i=0
    for line in input_file:
        i +=  1
    input_file.close()  # Put the file pointer back at top

    number_circle_locations = i

    # Create arrays of length i filled with zeros

    Circle_Location_file   = ["" for x in range(i)]

    CircleLat       = np.zeros(i)
    CircleLng       = np.zeros(i)
    Radius          = np.zeros(i)

    input_file = open("city_locations.txt", "r")

    i=-1
    for line in input_file:
        i+=1
        line    = line.strip()
        items   = line.split(',')

    #   Fill arrays

        items_array = np.asarray(items)

        Circle_Location_file[i]   = items_array[0]
        CircleLat[i]       = float(items_array[1])
        CircleLng[i]       = float(items_array[2])
        Radius[i]          = small_radius

    input_file.close()  # Put the file pointer back at top


    Current_Circle_Location = Circle_Location

#    if new_location_resp == 'y':
#        print ' Enter location (Case sensitive: Overrides previous parameter set):'
#        Circle_Location = raw_input()
#        region_type = 'Circle'

#    if new_location_resp != 'y':
#        Circle_Location = Current_Circle_Location
#        region_type = 'Circle'

    circle_location_flag = 0
    counter = 0

    while (circle_location_flag == 0):
        for j in range(0,number_circle_locations):

            counter += 1

            if Circle_Location == Circle_Location_file[j]:

                CircleCenterLat = CircleLat[j]
                CircleCenterLng = CircleLng[j]
                CircleRadius    = Radius[j]

                Circle_Lat         = float(CircleCenterLat)
                Circle_Lng         = float(CircleCenterLng)
                Radius_float       = float(CircleRadius)
 
                settings_params[0]  =   region_type
                settings_params[1]  =   completeness_mag
                settings_params[2]  =   earthquake_depth
                settings_params[3]  =   Circle_Location
                settings_params[4]  =   Circle_Lat
                settings_params[5]  =   Circle_Lng
                settings_params[6]  =   Radius_float
          
                circle_location_flag = 1

#   Write new value of Circle_Location to "Settings_File.txt"

    save_settings(settings_params)

    return (Circle_Location, Circle_Lat, Circle_Lng, Radius_float)

    #.................................................................

def get_polygon_data(Location):

#   Read Polygon_Location and data from "Settings_File.txt"

    settings_params = get_settings()
    default_settings_params = settings_params

    region_type = settings_params[0]
    completeness_mag    =   float(settings_params[1])
    earthquake_depth    =   float(settings_params[2])

    polygon_data = {}

    if region_type == 'Polygon':     #   If still a Polygon, proceed
        Polygon_Location     =   settings_params[3]

    if region_type != 'Polygon':     #   If not a Polygon, reset settings_params to null
        Polygon_Location    =   'None'

    polygon_data[0] = ['None', '0.0', '0.0', '0.0', '0.0', '0.0', '0.0', '0.0', '0.0',]    # Dummy List = value of dict for index[0]
    default_vertex_points = polygon_data[0]


   #
   #    Get the data for the Polygon: Read pre-defined locations file
   #

    input_file = open("polygonlocations.txt", "r")
    i=0
    for line in input_file:
        i +=  1
    input_file.close()  # Put the file pointer back at top

    number_polygon_locations = i

    # Create arrays of length i filled with zeros

    Polygon_Location_List   = ["" for x in range(i)]

    input_file = open("polygonlocations.txt", "r")

    polygon_data = {}

    i=-1
    for line in input_file:
        i+=1
        line    = line.strip()
        items   = line.split(',')
        Polygon_Location_List[i] = items[0]

#   print items for testing purposes

        vertex_points = []

        for j in range(0,len(items)):
            vertex_points.append(items[j])

        polygon_data[i] = vertex_points

    input_file.close()  # Put the file pointer back at top

    print(' ')
    print('     Current pre-defined Locations are: ')
    print(' ')

    for i in range(0,number_polygon_locations):
        print('        ', Polygon_Location_List[i])

    print(' ')
    print('     Current region is: ')
    print('        ', Location)
    print(' ')
    print('     Current polygon location is: ', Polygon_Location)
    print(' ')
    print('     Pick a new polygon location? (y/n):')
    new_location_resp   =   input()

    Current_Polygon_Location = Polygon_Location

    if new_location_resp == 'y':
        print(' Enter location (Case sensitive: Overrides previous parameter set):')
        Polygon_Location = input()
        region_type = 'Polygon'
        print('Polygon_Location: ', Polygon_Location)

    if new_location_resp != 'y':
        region_type = 'Polygon'
        print(' ')
        print(' Then we use the current region (which could be the dummy region)')
        print(' ')

    polygon_location_flag = 0
    counter = 0
    settings_params = []

    while (polygon_location_flag == 0):

        for i in range(0,number_polygon_locations):

            counter += 1

            if Polygon_Location == polygon_data[i][0]:
                polygon_location_flag = 1

                settings_params.append(region_type)
                settings_params.append(completeness_mag)
                settings_params.append(earthquake_depth)

                vertex_points = polygon_data[i]

                for j in range(0,len(vertex_points)):
                    settings_params.append(vertex_points[j])

        if polygon_location_flag == 0 and counter >= number_polygon_locations:
            polygon_location_flag = 1
            settings_params = default_settings_params
            vertex_points = default_vertex_points
            print(' ')
            print('     Invalid location, try again...')
            print(' ')
            print('     (Press any key to continue)')
            resp = input()
            print(' ')

#   Write new value of Polygon_Location to "Settings_File.txt"

    save_settings(settings_params)

    return (vertex_points)

    #.................................................................

def freqmagRegion(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag):

    print_data = 'TRUE'

    settings_params = get_settings()
    region_type = settings_params[0]
    Circle_Location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])

    #   Open the complete data file and collect the earthquakes for plotting

    data_file = open("USGS_master.catalog", "r")     #  This is all the data and all the small events

    #   Find the number of lines in the file

    i=0
    for line in data_file:
        i       +=  1

    data_file.close()  # Put the file pointer back at top

    number_eqs = i

    # Create arrays of length i filled with zeros

    mag                 =   zeros(number_eqs)

    # Bins for Number-magnitude plot

    min_mag = completeness_mag
    bin_diff= 0.1
    
    number_mag_bins     =   (max_mag - min_mag) / bin_diff + 5      #   Bin size = 0.1.  Assume min mag of interest is 3.0
    number_mag_bins     =   int(number_mag_bins)
    range_mag_bins      =   int(number_mag_bins)

    freq_mag_bins_pdf       =   zeros(number_mag_bins)
    freq_mag_bins_sdf       =   zeros(number_mag_bins)
    freq_mag_pdf_working    =   zeros(number_mag_bins)
    mag_array               =   zeros(number_mag_bins)  

    data_file = open("USGS_master.catalog", "r")     #  This is all the data and all the small events

    i=-1

    for line in data_file:

        i+= 1
        items = line.strip().split()
    #
    #   Remember that at this point, all the below variables are string variables, not floats
    #
        mag[i]          = float(items[5])
        bin_number      = int((mag[i]-min_mag)/bin_diff + 1 )
        if mag[i] >= completeness_mag:
            freq_mag_bins_pdf[bin_number]    +=  1

    data_file.close()                                               # Close the data file
    
    #.................................................................

    #   Tabulate the number of events in each bin

    for i in range(0,range_mag_bins):
        for j in range(i,range_mag_bins):                           # Loop over all bins to compute the GR cumulative SDF
            freq_mag_bins_sdf[i] += freq_mag_bins_pdf[j]
    print('')
    
#   print freq_mag_bins_sdf

    number_nonzero_bins=0
    for i in range(0,range_mag_bins):                               # Find the number of nonzero bins
        if freq_mag_bins_sdf[i] > 0:
            number_nonzero_bins+=1

    range_bins = int(number_nonzero_bins)                         # Find number of nonzero bins

    log_freq_mag_bins   =   zeros(number_nonzero_bins)              # Define the log freq-mag array

    for i in range(0,range_bins):
        if freq_mag_bins_sdf[i] > 0.0:
            log_freq_mag_bins[i] = -100.0                               # To get rid of it.
            log_freq_mag_bins[i] = math.log10(freq_mag_bins_sdf[i])     # Take the log-base-10 of the survivor function

    mag_bins  =   zeros(number_nonzero_bins)
    for i in range(0,range_bins):
        mag_bins[i]=min_mag + float(i)*bin_diff

    for i in range(0,number_mag_bins):
        mag_array[i]=min_mag + float(i)*bin_diff

    #.................................................................

#    if print_data == 'TRUE':
#        print ''
#        print mag_bins
#        print ''
#        print freq_mag_bins_pdf
#        print ''
#        print freq_mag_bins_sdf
#        print ''
#        print log_freq_mag_bins
#        print ''

    #.................................................................

    return mag_bins, log_freq_mag_bins, number_nonzero_bins

    ######################################################################

def freqmagCircle(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag):

    print_data = 'TRUE'

    settings_params = get_settings()
    region_type = settings_params[0]
    Circle_Location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])

    #   Open the complete data file and collect the earthquakes for plotting

    data_file = open("USGS_circle.catalog", "r")     #  This is all the data and all the small events

    #   Find the number of lines in the file

    i=0
    for line in data_file:
        i       +=  1

    data_file.close()  # Put the file pointer back at top

    number_eqs = i

    # Create arrays of length i filled with zeros

    mag                 =   zeros(number_eqs)

    # Bins for Number-magnitude plot

    min_mag = completeness_mag
    bin_diff= 0.1

    number_mag_bins     =   (max_mag - min_mag) / bin_diff + 5      #   Bin size = 0.1.  Assume min mag of interest is 3.0
    number_mag_bins     =   int(number_mag_bins)
    range_mag_bins      =   int(number_mag_bins)

    freq_mag_bins_pdf       =   zeros(number_mag_bins)
    freq_mag_bins_sdf       =   zeros(number_mag_bins)
    freq_mag_pdf_working    =   zeros(number_mag_bins)
    mag_array               =   zeros(number_mag_bins)  

    data_file = open("USGS_circle.catalog", "r")     #  This is all the data and all the small events

    i=-1

    for line in data_file:

        i+= 1
        items = line.strip().split()
    #
    #   Remember that at this point, all the below variables are string variables, not floats
    #
        mag[i]          = float(items[5])
        bin_number      = int((mag[i]-min_mag)/bin_diff + 1 )
        if mag[i] >= completeness_mag:
            freq_mag_bins_pdf[bin_number]    +=  1

    data_file.close()                                               # Close the data file

    #.................................................................

    #   Tabulate the number of events in each bin

    for i in range(0,range_mag_bins):
        for j in range(i,range_mag_bins):                           # Loop over all bins to compute the GR cumulative SDF
            freq_mag_bins_sdf[i] += freq_mag_bins_pdf[j]
    print('')

    number_nonzero_bins=0
    for i in range(0,range_mag_bins):                               # Find the number of nonzero bins
        if freq_mag_bins_sdf[i] > 0:
            number_nonzero_bins+=1

    range_bins = int(number_nonzero_bins)                         # Find number of nonzero bins

    log_freq_mag_bins   =   zeros(number_nonzero_bins)              # Define the log freq-mag array

    for i in range(0,range_bins):
        if freq_mag_bins_sdf[i] > 0.0:
            log_freq_mag_bins[i] = -100.0                               # To get rid of it.
            log_freq_mag_bins[i] = math.log10(freq_mag_bins_sdf[i])     # Take the log-base-10 of the survivor function

    mag_bins  =   zeros(number_nonzero_bins)
    for i in range(0,range_bins):
        mag_bins[i]=min_mag + float(i)*bin_diff

    for i in range(0,number_mag_bins):
        mag_array[i]=min_mag + float(i)*bin_diff

 
    #.................................................................

    return mag_bins, log_freq_mag_bins, number_nonzero_bins

    ######################################################################

def freqmagLastCircle(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag):

    print_data = 'TRUE'

    settings_params = get_settings()
    region_type = settings_params[0]
    Circle_Location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])

    #   Open the complete data file and collect the earthquakes for plotting

    data_file = open("USGS_last.circle.catalog", "r")     #  This is all the data and all the small events

    #   Find the number of lines in the file

    i=0
    for line in data_file:
        i       +=  1

    data_file.close()  # Put the file pointer back at top

    number_eqs = i

    # Create arrays of length i filled with zeros

    mag                 =   zeros(number_eqs)

    # Bins for Number-magnitude plot

    min_mag = completeness_mag
    bin_diff= 0.1

    number_mag_bins     =   (max_mag - min_mag) / bin_diff + 5      #   Bin size = 0.1.  Assume min mag of interest is 3.0
    number_mag_bins     =   int(number_mag_bins)
    range_mag_bins      =   int(number_mag_bins)

    freq_mag_bins_pdf       =   zeros(number_mag_bins)
    freq_mag_bins_sdf       =   zeros(number_mag_bins)
    freq_mag_pdf_working    =   zeros(number_mag_bins)
    mag_array               =   zeros(number_mag_bins)  

    data_file = open("USGS_last.circle.catalog", "r")     #  This is all the data and all the small events

    i=-1

    for line in data_file:

        i+= 1
        items = line.strip().split()
    #
    #   Remember that at this point, all the below variables are string variables, not floats
    #
        mag[i]          = float(items[5])
        bin_number      = int((mag[i]-min_mag)/bin_diff + 1 )
        if mag[i] >= completeness_mag:
            freq_mag_bins_pdf[bin_number]    +=  1

    data_file.close()                                               # Close the data file

    #.................................................................

    #   Tabulate the number of events in each bin

    for i in range(0,range_mag_bins):
        for j in range(i,range_mag_bins):                           # Loop over all bins to compute the GR cumulative SDF
            freq_mag_bins_sdf[i] += freq_mag_bins_pdf[j]
    print('')

    number_nonzero_bins=0
    for i in range(0,range_mag_bins):                               # Find the number of nonzero bins
        if freq_mag_bins_sdf[i] > 0:
            number_nonzero_bins+=1

    range_bins = int(number_nonzero_bins)                         # Find number of nonzero bins

    log_freq_mag_bins   =   zeros(number_nonzero_bins)              # Define the log freq-mag array

    for i in range(0,range_bins):
        if freq_mag_bins_sdf[i] > 0.0:
            log_freq_mag_bins[i] = -100.0                               # To get rid of it.
            log_freq_mag_bins[i] = math.log10(freq_mag_bins_sdf[i])     # Take the log-base-10 of the survivor function

    mag_bins  =   zeros(number_nonzero_bins)
    for i in range(0,range_bins):
        mag_bins[i]=min_mag + float(i)*bin_diff

    for i in range(0,number_mag_bins):
        mag_array[i]=min_mag + float(i)*bin_diff

    #.................................................................

#    if print_data == 'TRUE':
#        print ''
#        print mag_bins
#        print ''
#        print freq_mag_bins_pdf
#        print ''
#        print freq_mag_bins_sdf
#        print ''
#        print log_freq_mag_bins
#        print ''

    #.................................................................

    return mag_bins, log_freq_mag_bins, number_nonzero_bins

    ######################################################################

def freqmagLast(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag):

    print_data = 'TRUE'

    settings_params = get_settings()
    region_type = settings_params[0]
    Circle_Location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])

    #   Open the complete data file and collect the earthquakes for plotting

    data_file = open("USGS_last.catalog", "r")     #  This is all the data and all the small events

    #   Find the number of lines in the file

    i=0
    for line in data_file:
        i       +=  1

    data_file.close()  # Put the file pointer back at top

    number_eqs = i

    # Create arrays of length i filled with zeros

    mag                 =   zeros(number_eqs)

    # Bins for Number-magnitude plot

    min_mag = completeness_mag
    bin_diff= 0.1

    number_mag_bins     =   (max_mag - min_mag) / bin_diff + 5      #   Bin size = 0.1.  Assume min mag of interest is 3.0
    number_mag_bins     =   int(number_mag_bins)
    range_mag_bins      =   int(number_mag_bins)

    freq_mag_bins_pdf       =   zeros(number_mag_bins)
    freq_mag_bins_sdf       =   zeros(number_mag_bins)
    freq_mag_pdf_working    =   zeros(number_mag_bins)
    mag_array               =   zeros(number_mag_bins)  

    data_file = open("USGS_last.catalog", "r")     #  This is all the data and all the small events

    i=-1

    for line in data_file:

        i+= 1
        items = line.strip().split()
    #
    #   Remember that at this point, all the below variables are string variables, not floats
    #
        mag[i]          = float(items[5])
        bin_number      = int((mag[i]-min_mag)/bin_diff + 1 )
        if mag[i] >= completeness_mag:
            freq_mag_bins_pdf[bin_number]    +=  1

    data_file.close()                                               # Close the data file

    #.................................................................

    #   Tabulate the number of events in each bin

    for i in range(0,range_mag_bins):
        for j in range(i,range_mag_bins):                           # Loop over all bins to compute the GR cumulative SDF
            freq_mag_bins_sdf[i] += freq_mag_bins_pdf[j]
    print('')

    number_nonzero_bins=0
    for i in range(0,range_mag_bins):                               # Find the number of nonzero bins
        if freq_mag_bins_sdf[i] > 0:
            number_nonzero_bins+=1

    range_bins = int(number_nonzero_bins)                         # Find number of nonzero bins

    log_freq_mag_bins   =   zeros(number_nonzero_bins)              # Define the log freq-mag array

    for i in range(0,range_bins):
        if freq_mag_bins_sdf[i] > 0.0:
            log_freq_mag_bins[i] = -100.0                               # To get rid of it.
            log_freq_mag_bins[i] = math.log10(freq_mag_bins_sdf[i])     # Take the log-base-10 of the survivor function

    mag_bins  =   zeros(number_nonzero_bins)
    for i in range(0,range_bins):
        mag_bins[i]=min_mag + float(i)*bin_diff

    for i in range(0,number_mag_bins):
        mag_array[i]=min_mag + float(i)*bin_diff

    #.................................................................

#    if print_data == 'TRUE':
#        print ''
#        print mag_bins
#        print ''
#        print freq_mag_bins_pdf
#        print ''
#        print freq_mag_bins_sdf
#        print ''
#        print log_freq_mag_bins
#        print ''

    #.................................................................

    return mag_bins, log_freq_mag_bins, number_nonzero_bins

    ######################################################################

def freqmagCombined(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag, last_eq_date, last_eq_mag, depth, city_circle):

    print_data = 'FALSE'

    settings_params = get_settings()
    region_type = settings_params[0]
    Circle_Location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])

    min_mag = completeness_mag

    mag_bins_circle, log_freq_mag_bins_circle, number_nonzero_bins_circle = freqmagCircle(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag)

    mag_bins_region, log_freq_mag_bins_region, number_nonzero_bins_region = freqmagRegion(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag)
    
    mag_bins_last, log_freq_mag_bins_last, number_nonzero_bins_last = freqmagLast(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag)

    mag_bins_last_circle, log_freq_mag_bins_last_circle, number_nonzero_bins_last_circle = freqmagLastCircle(NELat, NELng, SWLat, SWLng, MagLo, Location, max_mag)

    number_mag_bins = len(mag_bins_region)

    #.................................................................

#
#     Fit the line to find the b-value in the region
#

    xr    =   zeros(number_mag_bins)
    yr    =   zeros(number_mag_bins)

    mag1 = min_mag + 0.25
    mag2 = min_mag + 2.5

#    if print_data == 'TRUE':
#        print ' '
#        print mag1, mag2

    #   Here us where we count the number of data to fit, then define xr[:] and yr[:]

    xr    =   zeros(1000)
    yr    =   zeros(1000)

    k = -1
    for i in range(0,number_nonzero_bins_region):
        if (mag_bins_region[i] >= mag1) and (mag_bins_region[i] <= mag2):
            k = k + 1
            xr[k] = mag_bins_region[i]
            yr[k] = log_freq_mag_bins_region[i]
            if print_data == 'TRUE':
                print(' k, xr, yr: ', k, xr[k], yr[k])

    kmax = k+1

    if kmax > 1:
        slope, cept, errs, errc, s2 = linfit(xr,yr, kmax)
        bval = - slope
#        print ' '
#        print ' b-value for the region is:'
#        print   bval,' +/- ',errs
#        print ' '
#        print ' Intercept for the region is: ', cept
#        print ' '


    #.................................................................

    plotmin = 0.0
    plotmax = int(log_freq_mag_bins_region[0] + 1.0)

    plt.plot(mag_bins_region, log_freq_mag_bins_region, 'bs')
    plt.plot(mag_bins_region, log_freq_mag_bins_region, 'bs', fillstyle='none', markeredgecolor='k', lw=0.4)
    
#   plt.plot(mag_bins_circle, log_freq_mag_bins_circle, 'go')
#   plt.plot(mag_bins_last, log_freq_mag_bins_last, 'go')

    plt.plot(mag_bins_last_circle, log_freq_mag_bins_last_circle, 'go')
    plt.plot(mag_bins_last_circle, log_freq_mag_bins_last_circle, 'go', fillstyle='none', markeredgecolor='k', lw=0.4)
    
    plt.ylim(plotmin, plotmax)
    plt.xlim(min_mag, max_mag)

    City = Location.split('_')
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]

    SupTitle_text = 'Number-Magnitude for Earthquakes near ' + City_Location 
    Title_text = 'Circle:  EQs after M' + last_eq_mag + ' on ' + last_eq_date + ', R < ' + str(city_circle) + ' km, ' + 'D < ' + str(depth) + ' km'
    plt.suptitle(SupTitle_text, fontsize=14)
    plt.title(Title_text, fontsize=12)

    plt.xlabel('Magnitude', fontsize=14)
    plt.ylabel('Log$_{10}$ ( Number )', fontsize=14)

    text_x      = (max_mag-min_mag)*0.30 + min_mag
    text_y      = (plotmax-plotmin) * 0.95 + plotmin
    bval        = '%.2f'%(bval)
    error       = '%.2f'%(errs)
    text_string = 'b-value for Region:  ' + bval + ' +/- ' + error
    plt.text(text_x,text_y,text_string, fontsize=12)

    x_pos = (max_mag-min_mag)*0.30 + min_mag
    y_pos = (plotmax-plotmin) * (0.875 + 0.015) + plotmin
    plt.plot(x_pos, y_pos, 'bs')
    plt.plot(x_pos, y_pos, 'bs', fillstyle='none', markeredgecolor='k', lw=0.4)
    text_x = x_pos + (max_mag-min_mag)*0.025
    text_y = (plotmax-plotmin) * (0.875) + plotmin
    text_string = 'EQs in Region'
    plt.text(text_x,text_y,text_string, fontsize=12)

    x_pos = (max_mag-min_mag)*0.30 + min_mag
    y_pos = (plotmax-plotmin) * (0.825 + 0.015) + plotmin 
    plt.plot(x_pos, y_pos, 'go')
    plt.plot(x_pos, y_pos, 'go', fillstyle='none', markeredgecolor='k', lw=0.4)
    text_x = x_pos + (max_mag-min_mag)*0.025
    text_y = (plotmax-plotmin) * (0.825) + plotmin
    text_string = 'EQs in Circle'
    plt.text(text_x,text_y,text_string, fontsize=12)


    if (kmax > 1):

    #   Plot the best fitting line for the region

        x1 = xr[kmax-1]                 # Note that xr[kmax-1] is the largest magnitude that was used to fit the line
        y1 = slope*xr[kmax-1] + cept
        x2 = max_mag
        y2 = slope*max_mag + cept
        plt.plot([x1, x2], [y1, y2], 'r--', lw=1.15)

        x1 = mag1
        y1 = slope*mag1 + cept
        x2 = xr[kmax-1]
        y2 = slope*xr[kmax-1] + cept
        plt.plot([x1, x2], [y1, y2], 'r-', lw=1.15)

    #   Plot the best fitting line for the circle with last earthquakes


        try:
            mag_cept = 5
            if mag_cept >= len(mag_bins_last_circle):
                mag_cept = len(mag_bins_last_circle) - 1

    #   Same slope different intercept
            cept = log_freq_mag_bins_last_circle[mag_cept] - slope * mag_bins_last_circle[mag_cept]   

            x1 = min_mag + 0.25               
            y1 = slope*x1 + cept
            x2 = max_mag
            y2 = slope*max_mag + cept
            plt.plot([x1, x2], [y1, y2], 'b--', lw=1.15)
            
        except:
            pass


    #.................................................................


    figure_name_png = './Data/' + Circle_Location + '_Number-Magnitude.png'

#    matplotlib.pyplot.savefig(figure_name)
#    matplotlib.pyplot.close('all')

    plt.savefig(figure_name_png, dpi=300)
    plt.close('all')
    
    return bval, errs
    
    ######################################################################
    
def TM_metric(NELat, NELng, SWLat, SWLng, MagLo, Location, Country):

    #   Get the time series
    
    data_array, n_times, n_boxes, time_first_eq, time_last_eq, down_scale, filter_magnitude, filter_year = \
            MCUtilities.mesh_seismicity(Country, NELat, NELng, SWLat, SWLng, MagLo)
    
    n_times = int(n_times)
    time_increment = (float(time_last_eq) - float(time_first_eq))/float(n_times)
    
    time_array = np.zeros(n_times)
    time_array[0] = float(time_first_eq)
   
    #   Define the running time average
    
    running_time_avg = np.zeros((n_boxes,n_times))
    
    for box_index in range(0,n_boxes):
        for time_index in range(1,n_times):
            running_time_avg[box_index][time_index] = running_time_avg[box_index][time_index-1] + data_array[box_index][time_index]
    #        print '0000 - box, time, running_time_avg[i][time_index]: ', box_index, time_index, running_time_avg[box_index][time_index]
                
        for time_index in range(1,n_times):
            
        #   This next division by float(time_index) should be divide by actual time, I think
            running_time_avg[box_index][time_index] = running_time_avg[box_index][time_index]/(time_increment * time_index)
            
            if box_index == 0:
                time_array[time_index] = time_first_eq + time_increment * time_index
    #           print 'time_index, time_array[time_index]: ', time_index, time_array[time_index]
            
    #   Now define the spatial average of the running time average
    
    box_avg_running_time_avg = np.zeros(n_times)
    
    Omega = np.zeros(n_times)
    
    for time_index in range(1,n_times):
        
        for i in range(0,int(n_boxes)):
            box_avg_running_time_avg[time_index] += running_time_avg[i][time_index]

    #    print 'time, box_avg_running_time_avg[relative_time]: ', relative_time, box_avg_running_time_avg[relative_time]
        
        box_avg_running_time_avg[time_index] = box_avg_running_time_avg[time_index]/float(n_boxes)
        
        #   Compute Thirumalai- Mountain metric

        for i in range(0,int(n_boxes)):
            Omega[time_index] += (running_time_avg[i][time_index] -  box_avg_running_time_avg[time_index])**2
            
        Omega[time_index] = Omega[time_index]/float(n_boxes)
        if Omega[time_index] < 0.0001:
            Omega[time_index] = 100.0
        Omega[time_index] = 1./(Omega[time_index])
    
    #   Two y-axes: https://matplotlib.org/examples/api/two_scales.html
    
    #.................................................................
    
    date_string, time_string, yrs, lng, lat, mag, dep, number_eqs = magtime_data(NELat, NELng, SWLat, SWLng, MagLo, Location, filter_year)
    
    fig, ax1 = plt.subplots()
    
    #.................................................................
    
    #   First sub-plot:  Large earthquake magnitude vs time
    
    for i in range(0,number_eqs):
        if mag[i] >= 5.5:
            x1=yrs[i]
            x2=x1
            y1=5.5
            y2=mag[i]
            ax1.plot([x1,x2],[y1,y2],'b-', lw = 1.0)
            ax1.plot(yrs[i], mag[i], 'ro', ms=3)
            
#   ax1.plot(yrs, mag, 'o', fillstyle='none', color='k', ms=3, lw=0.6)

    ax1.set_ylabel('Magnitude', color='k')
    ax1.tick_params('y', colors='k')
    ax1.set_ylim([5.5, 9.5])
    
    CG_size = 1.0/down_scale
    CG_size = "{0:.2f}".format(CG_size)
    
    filter_magnitude = "{0:.2f}".format(filter_magnitude)
    
    City = Location.split('_')
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]
    
    CG_size = str(CG_size)
    
    SupTitle_text = 'EQs and TM Metric for Region near ' + City_Location 
    Title_text = 'Box Size: ' + '$' + CG_size + '^{o}$ x ' + '$' + CG_size + '^{o}$' + '    Cutoff Magnitude: M > ' + filter_magnitude
   
    plt.suptitle(SupTitle_text, fontsize=14)
    plt.title(Title_text, fontsize=12)

    #.................................................................
    
    #   Second sub-plot:  Inverse TM Metric
    
    ax2 = ax1.twinx()
    
    ax2.plot(time_array, Omega, 'k-', lw=1.15)
    ax2.set_xlabel('Time (Years)', fontsize=12)
    ax2.set_ylabel('Inverse TM Metric', fontsize=12)
    ax2.tick_params('y', colors='k')
    
    #.................................................................
    
    figure_name = './Data/' + Location + '_TM_Metric.png'

  # plt.show()
    plt.savefig(figure_name,dpi=300)
    plt.close('all')

    return None
    
    ######################################################################
    
def magtime_data(NELat, NELng, SWLat, SWLng, MagLo, Location, filter_year):

    #   Open input file

#    input_file = open("EQ_Working_Catalog.txt", "r")
    input_file = open("USGS_master.catalog", "r")

    #   Find the number of lines in the file

    i=0
    for line in input_file:
        i       +=  1

    input_file.close()  # Put the file pointer back at top

    number_eqs = i
    
    #input_file = open("EQ_Working_Catalog.txt", "r")
    input_file = open("USGS_master.catalog", "r")


    # Create arrays of length i filled with zeros

    indx_string         =   ["" for x in range(i)]
    yrs                 =   zeros(i)
    lng                 =   zeros(i)
    lat                 =   zeros(i)
    mag                 =   zeros(i)
    dep                 =   zeros(i)
    time_string         =   ["" for x in range(i)]
    date_string         =   ["" for x in range(i)]

    # Loop over lines and extract variables of interest

    i=-1
    for line in input_file:

        line = line.strip()
        data = line.split()
        
        if float(data[2]) >= filter_year:
            i       +=  1

#           indx_string[i] =   data[0]
            date_string[i] =   data[0]
            time_string[i] =   data[1]

            yrs[i]     =    float(data[2])
            lng[i]     =    float(data[3])
            lat[i]     =    float(data[4])
            mag[i]     =    float(data[5])
            dep[i]     =    float(data[6])
        
    input_file.close()

    return (date_string, time_string, yrs, lng, lat, mag, dep, number_eqs)
    
    ###########################################################################
    
def countdown_region_circle(NELat, NELng, SWLat, SWLng, MagLo, Location):

    print_data = 'TRUE'

    last_droplet_plot   =   'n'

    settings_params = get_settings()
    region_type = settings_params[0]
    Circle_Location = settings_params[3]

    if region_type == 'Circle':
        completeness_mag = float(settings_params[1])
        earthquake_depth = float(settings_params[2])


    #   Open input file

    input_file = open("EQ_Working_Catalog.txt", "r")

    #   Find the number of lines in the file

    i=0
    for line in input_file:
        i +=  1

    input_file.close()  # Put the file pointer back at top

    number_eqs = i

    input_file = open("EQ_Working_Catalog.txt", "r")

    # Create arrays of length i filled with zeros

    indx_string         =   ["" for x in range(number_eqs)]
    yrs                 =   zeros(number_eqs)
    lng                 =   zeros(number_eqs)
    lat                 =   zeros(number_eqs)
    mag                 =   zeros(number_eqs)
    dep                 =   zeros(number_eqs)

    time_string         =   ["" for x in range(number_eqs)]
    date_string         =   ["" for x in range(number_eqs)]

    # Loop over lines and extract variables of interest

    i=-1
    eq_sequence_number = 0

    for line in input_file:
        line = line.strip()
        data = line.split()
        data_array = np.asarray(data)

        i       +=  1

        indx_string[i] =   data_array[0]
        date_string[i] =   data_array[1]
        time_string[i] =   data_array[2]

        yrs[i]     =    float(data_array[3])
        lng[i]     =    float(data_array[4])
        lat[i]     =    float(data_array[5])
        mag[i]     =    float(data_array[6])
        dep[i]     =    float(data_array[7])

    # Format and print the earthquake sequence numbers

        if mag[i] >= MagLo:
            eq_sequence_number += 1

        last_eq = eq_sequence_number

    #.................................................................

     #   The large earthquakes were renumbered to start from 1 so need to correct for that

    first_eq    = int(0)
    second_eq   = int(last_eq) - 1

    number_of_eq_cycles = last_eq - first_eq

    input_file.close()  # Put the file pointer back at top

    #.................................................................
    

    #   Now open the complete data file so that we can retrieve the small earthquakes    

    #   Count the number of small earthquakes in each cycle and store in array for binning
    #       and plotting in histogram

    number_small_eq_array   =   np.zeros(number_eqs)

    data_file = open("USGS_master.catalog", "r")     #  This is all the data and all the small events

    index_large_eq = -1             #   So the first large earthquake cycle will have index 0
    large_eq_flag = 'FALSE'

    for line in data_file:
        items   = line.strip().split()
        mag_query           = float(items[5])

        if mag_query < MagLo:
            date_small_quake    = items[0]
            time_small_quake    = items[1]

        if mag_query >= MagLo:
            large_eq_flag = 'TRUE'  #   Takes care of initial state where there is no initial large earthquake
            number_in_cycle =  0
            index_large_eq += 1
        if (mag_query < MagLo) and (mag_query >= float(completeness_mag)) and (large_eq_flag == 'TRUE'):
            number_small_eq_array[index_large_eq] += 1
    
    data_file.close()               #   Close the data file

    #.................................................................

    print(' ')
    print('       Large EQ', '      Date and Time', '       Magnitude', '   Latitude', '    Longitude', '    Number Small EQs')
    print(' ')

    total_number_small_eqs = 0
    eq_limit = second_eq-first_eq +1  
    
    for i in range(first_eq,eq_limit):
        total_number_small_eqs += number_small_eq_array[i]
        if i+1 <10:
            blank_space = '         '
        if i+1 >=10:
            blank_space = '        '
        if i+1 >=100:
            blank_space = '       '
        print(blank_space, i+1, '     ', date_string[i] + ' ' + time_string[i], '     ', '%.2f'%mag[i], '     ', '%.3f'%(lat[i]), '    ', '%.3f'%lng[i],  \
                '          ',int(number_small_eq_array[i]))

    #.................................................................

    range_limit = len(lat)

    print_text_1 = '     Found ' + str(number_eqs) + ' earthquakes having M>' + str(MagLo) + ' around ' + Location
    print_text_2 = '     Occurring from: ' + date_string[0] + ' ' + time_string[0] 
    print_text_3 = '               thru: ' + date_string[number_eqs-1] + ' ' + time_string[number_eqs - 1]
    print(' ')
    print(print_text_1)
    print(' ')
    print(print_text_2)
    print(print_text_3)
    print('')
    print('     Total Number of Small Earthquakes: ', int(total_number_small_eqs))        
    print('')

   #.................................................................

   #
   #    Get the data on the circular region

    settings_params = get_settings()

    earthquake_depth    =   float(settings_params[2])
    completeness_mag    =   settings_params[1]
    Circle_Location     =   settings_params[3]
    Circle_Lat          =   float(settings_params[4])
    Circle_Lng          =   float(settings_params[5])
    Radius_float        =   float(settings_params[6])

#     mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = get_circle_catalog(Circle_Lat, Circle_Lng, Radius_float, MagLo)
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = read_circle_catalog()

   #    Reverse the magnitude array for the magnitudes of events in the circular region

    mag_array_reversed  =   list(reversed(mag_array))
    date_array_reversed =   list(reversed(date_array))
    time_array_reversed =   list(reversed(time_array))
    year_array_reversed =   list(reversed(year_array))
    depth_array_reversed=   list(reversed(depth_array))
    lat_array_reversed  =   list(reversed(lat_array))
    lng_array_reversed  =   list(reversed(lng_array))


   #    Now find the number of small events within the circle since the large event
   
   #    Now we need to filter the large eq cycles that have at least as many small 
   #        earthquakes that have occurred 

    todays_count = 0    

    last_eq_mag     = '(No Data)'
    last_eq_date    = '(No Data)'
    last_eq_time    = '(No Data)'

   #.................................................................
   #
   #   This next bit finds the data on the last big earthquake

    mag_flag = 0
    for i in range(0,len(mag_array_reversed)):
        if float(mag_array_reversed[i]) >= MagLo and (mag_flag == 0) and (float(depth_array_reversed[i]) <= earthquake_depth):

            last_eq_mag         = str(round(float(mag_array_reversed[i]),2))
            last_eq_date        = str(date_array_reversed[i])
            last_eq_time        = str(time_array_reversed[i])  
            
            print('last_eq_mag,last_eq_date,last_eq_time: ', last_eq_mag,last_eq_date,last_eq_time)

            mag_flag = 1
        if float(mag_array_reversed[i]) < MagLo and mag_flag == 0:
            todays_count += 1

    print('')
    print('Todays Count: ', todays_count)
   #.................................................................
   

    #   Now go through the catalog again to determine which region cycles have at least
    #       enough small events equal to the number in the city circle since the last large
    #       event within the city circle    

    percent_25_array    =   []
    percent_75_array    =   []
    percent_99_array    =   []
    median_count_array  =   []
    nat_time_array      =   []
    mean_count_array    =   []

    total_number_intervals = len(number_small_eq_array)
    max_loop_index = total_number_intervals - 2     #   This will be the max loop index
    max_counts = int(max(number_small_eq_array))
    
#     print ''
#     print 'Max Loop Index: ', max_loop_index
    
    median_count_today = '(No Data)'
    p25_today = '(No Data)'
    p75_today = '(No Data)'
    
    median_flag = 'true'
#    median_flag = 'false'

    #   .............................................................

    bins = []
    cum_prob = []

    fname = 'probability_file.txt'
    data_prob = open(fname,'r')

    for line in data_prob:
        x=line.split()
        bins.append(float(x[0]))
        cum_prob.append(float(x[1])*.01)
    
    data_prob.close()
    
    #   .............................................................
    #
    #   Compute weights
    

    weight_array    =   []
    k_value = 0
    
    for running_count in range(0,max_counts):
        for k in range(0,len(bins)):
#       print 'running_count, bins[k], cum_prob[k]: ', running_count,bins[k]
            if float(running_count) >= float(bins[k]):
                k_value = k
            
        weight_array.append(1.0 - cum_prob[k_value])
                
#        print 'running_count, weight: ', running_count, weight_array[running_count]
        
    #   .............................................................
    
    for running_count in range(0,max_counts):
        median_countdown,percent_25,percent_75,percent_99,mean_future_count,mean_future_stdev, number_usable_intervals = \
                MCUtilities.median_value_intervals(number_small_eq_array,running_count,median_flag)

        weight = float(number_usable_intervals)/float(total_number_intervals)
#       weight = weight_array[running_count]   #   This is identical to the above weighting

#       weight = 1.0    #   Gives basically a Poisson distribution, i.e., flat as a pancake
        
        if median_countdown != '(No Data)':
#           print 'median_countdown, mean_countdown: ', median_countdown, mean_future_count
            median_count_array.append(float(median_countdown)*weight)
            mean_count_array.append(float(mean_future_count)*weight)
            percent_25_array.append(float(percent_25)*weight)
            percent_75_array.append(float(percent_75)*weight)
            percent_99_array.append(float(percent_99)*weight)
        
            nat_time_array.append(running_count)
        
            if running_count == todays_count:
                median_count_today = int(round(float(median_countdown)*weight,0))
                mean_count_today = int(round(float(mean_future_count)*weight,0))
                p25_today = int(round(float(percent_25)*weight,0))
                p75_today = int(round(float(percent_75)*weight,0))
                p99_today = int(round(float(percent_99)*weight,0))
            
#                print ''
#                print 'median_count_today', median_count_today
#                print 'mean_count_today: ', mean_count_today
#                print 'p25_today: ', p25_today
#                print 'p75_today: ', p75_today
#                print 'p99_today: ', p99_today
#                print ''
        
    City = Location.split('_')
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]
        
    SupTitle_text = 'Residual Lifetime Exceedance Countdown for M>' + str(MagLo)
    
    Title_text    = 'After M' + last_eq_mag + ' on ' + last_eq_date + ' at ' + last_eq_time + ' Near ' + City_Location
   
    figure_name_png = './Data/' + Circle_Location + '_Countdown.png'
    
    plt.fill_between(nat_time_array,percent_25_array,percent_75_array, alpha = 0.75, facecolor='yellow', interpolate=True)
    
    plt.plot(nat_time_array,percent_25_array,'b--')
    plt.plot(nat_time_array,median_count_array,'r-')
    plt.plot(nat_time_array,mean_count_array,'g-')
    plt.plot(nat_time_array,percent_75_array,'b--')
        
    ymin, ymax = plt.ylim()
    xmin, xmax = plt.xlim()
    
    #   Plot vertical line at todays count
    
    x = [todays_count,todays_count]
    y = [ymin,0.5*ymax]
    plt.plot(x,y,'k--',lw=1.15)
    
    plt.suptitle(SupTitle_text, fontsize=14)
    plt.title(Title_text, fontsize=12)
    
    plt.xlabel('Number of Small Earthquakes since Last M>'+str(MagLo)+ ' Earthquake')
    plt.ylabel('Countdown to Next M>'+ str(MagLo)+ ' Earthquake')

    if median_count_today != '(No Data)':
        
        text_x      = (xmax-xmin)*0.1 + xmin
        text_y      = (ymax-ymin) * 0.95 + ymin
        text_string = 'Todays M>'+ str(completeness_mag) + ' EQ Count:  ' + str(todays_count)
        plt.text(text_x,text_y,text_string, fontsize=9)    
        
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.95 + ymin
        text_string = 'Mean (Green) Lifetime: ' + str(mean_count_today)
        plt.text(text_x,text_y,text_string, fontsize=9)    
        
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.875 + ymin
        text_string = 'Median (Red) Lifetime: ' + str(median_count_today)
        plt.text(text_x,text_y,text_string, fontsize=9)    
    
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.825 + ymin
        text_string = '            25% Lifetime: ' + str(p25_today)
        plt.text(text_x,text_y,text_string, fontsize=9) 
    
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.775 + ymin
        text_string = '            75% Lifetime: ' +  str(p75_today)
        plt.text(text_x,text_y,text_string, fontsize=9) 
        
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.725 + ymin
        text_string = '            99% Lifetime: ' +  str(p75_today)
#        plt.text(text_x,text_y,text_string, fontsize=9) 
        
        
#   plt.show()
    plt.savefig(figure_name_png,dpi=300)
#    plt.savefig(figure_name_pdf)
    plt.close('all')
    
    #   .............................................................

    percent_25_array    =   []
    percent_75_array    =   []
    percent_99_array    =   []
    median_count_array  =   []
    nat_time_array      =   []
    mean_count_array    =   []
    
    for running_count in range(0,max_counts):
        median_countdown,percent_25,percent_75,percent_99,mean_future_count,mean_future_stdev, number_usable_intervals = \
                MCUtilities.median_value_intervals(number_small_eq_array,running_count,median_flag)

        
        if median_countdown != '(No Data)':

            median_count_array.append(float(median_countdown))
            mean_count_array.append(float(mean_future_count))
            percent_25_array.append(float(percent_25))
            percent_75_array.append(float(percent_75))
            percent_99_array.append(float(percent_99))
            
            nat_time_array.append(running_count)
        
            if running_count == todays_count:
                median_count_today = int(round(float(median_countdown),0))
                mean_count_today = int(round(float(mean_future_count),0))
                p25_today = int(round(float(percent_25),0))
                p75_today = int(round(float(percent_75),0))
                p99_today = int(round(float(percent_99),0))
            
#                 print ''
#                 print 'median_count_today', median_count_today
#                 print 'mean_count_today: ', mean_count_today
#                 print 'p25_today: ', p25_today
#                 print 'p75_today: ', p75_today
#                 print 'p99_today: ', p99_today
                print('')
        
    City = Location.split('_')
    Number_Spaces = len(City)

    Location_Actual = City[0] + ' '
    for i in range(1,Number_Spaces):
        Location_Actual += City[i] + ' '

    City_Location = Location_Actual[:-1]
        
    SupTitle_text = 'Unweighted Residual Lifetime for M>' + str(MagLo)
    
    Title_text    = 'After M' + last_eq_mag + ' on ' + last_eq_date + ' at ' + last_eq_time + ' Near ' + City_Location
   
    figure_name_pdf = './Data/' + Circle_Location + '_Unweighted_Countdown.png'
    
    plt.fill_between(nat_time_array,percent_25_array,percent_75_array, alpha = 0.75, facecolor='yellow', interpolate=True)
    
    plt.plot(nat_time_array,percent_25_array,'b--')
    plt.plot(nat_time_array,median_count_array,'r-')
    plt.plot(nat_time_array,mean_count_array,'g-')
    plt.plot(nat_time_array,percent_75_array,'b--')
        
    ymin, ymax = plt.ylim()
    xmin, xmax = plt.xlim()
    
    #   Plot vertical line at todays count
    
    x = [todays_count,todays_count]
    y = [ymin,ymax]
    plt.plot(x,y,'k--',lw=1.15)
    
    plt.suptitle(SupTitle_text, fontsize=14)
    plt.title(Title_text, fontsize=12)
    
    plt.xlabel('Number of Small Earthquakes since Last M>'+str(MagLo)+ ' Earthquake')
    plt.ylabel('Countdown to Next M>'+ str(MagLo)+ ' Earthquake')

    if median_count_today != '(No Data)':
        
        text_x      = (xmax-xmin)*0.1 + xmin
        text_y      = (ymax-ymin) * 0.95 + ymin
        text_string = 'Todays M>' + str(completeness_mag) + ' EQ Count:  ' + str(todays_count)
        plt.text(text_x,text_y,text_string, fontsize=9)    
        
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.95 + ymin
        text_string = 'Mean (Green) Lifetime: ' + str(mean_count_today)
        plt.text(text_x,text_y,text_string, fontsize=9)    
        
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.875 + ymin
        text_string = 'Median (Red) Lifetime: ' + str(median_count_today)
        plt.text(text_x,text_y,text_string, fontsize=9)    
    
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.825 + ymin
        text_string = '            25% Lifetime: ' + str(p25_today)
        plt.text(text_x,text_y,text_string, fontsize=9) 
    
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.775 + ymin
        text_string = '            75% Lifetime: ' +  str(p75_today)
        plt.text(text_x,text_y,text_string, fontsize=9) 
        
        text_x      = (xmax-xmin)*0.6 + xmin
        text_y      = (ymax-ymin) * 0.725 + ymin
        text_string = '            99% Lifetime: ' +  str(p75_today)
#        plt.text(text_x,text_y,text_string, fontsize=9) 
        
        
#   plt.show()
    plt.savefig(figure_name_png,dpi=300)
#    plt.savefig(figure_name_pdf)
    
    plt.close('all')
    
    print('')
    print('Todays Median Count to next big event is: ', median_count_today)

    return 
